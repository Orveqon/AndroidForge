# Neon Flip — Game Architecture & Technical Guide

## Overview
**Neon Flip** is a high-speed cyberpunk arcade endless runner built with modern HTML5 Canvas, Web Audio API, and wrapped in a high-performance Android native runtime featuring Google AdMob (SDK v23.6.0) and User Messaging Platform (UMP) consent.

## Architecture & Systems
1. **Engine & Loop**: `src/main.js` orchestrates a 60 FPS `requestAnimationFrame` loop with delta-time clamping to prevent stuttering on lower-memory Android devices.
2. **Viewport Scaling**: `src/pixelfork/gameViewport.js` uses aspect-fit virtual canvas coordinates (480x800) with High-DPI Retina pixel-ratio scaling.
3. **Player Physics**: `src/runner.js` handles zero-latency gravity flips with EaseInOut cubic curve, full 180° rotation, particle bursts, and motion trail rendering.
4. **Procedural Hazards**: Rhythm-calibrated hazard patterns (floor spikes, ceiling spikes, alternating gauntlets, and pulsing laser barriers) with dynamic speed-adjusted spacing.
5. **Shop & Upgrades**: 6 distinct unlockable neon skins, 3 powerup upgrades (Energy Shield, Spark Magnet, Double Sparks), all persisted in `src/profile.js`.
6. **Audio Engine**: `src/audio.js` provides procedural Web Audio synthesis for swooshes, chime arpeggios, shields, and explosions with zero missing audio assets.
7. **AdMob Bridge**: `src/integrations.js` coordinates Banner, Interstitial, and verified Rewarded Ads with Android native `AdMobManager`.
