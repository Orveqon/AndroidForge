# Neon Flip — Android AdMob & Native Integration

## AdMob Architecture
The Android wrapper uses Google Mobile Ads SDK (`play-services-ads:23.6.0`) and Google User Messaging Platform (`user-messaging-platform:3.1.0`).

### Ad Units Configuration
- **Development / Debug Mode**: Official Google Test Ad IDs are automatically used in debug builds (`buildConfigField` in `app/build.gradle.kts`).
  - App ID: `ca-app-pub-3940256099942544~3347511713`
  - Banner: `ca-app-pub-3940256099942544/6300978111`
  - Interstitial: `ca-app-pub-3940256099942544/1033173712`
  - Rewarded: `ca-app-pub-3940256099942544/5224354917`
- **Production / Release Mode**: Production Ad IDs are configured exclusively for `release` builds.
  - App ID: `ca-app-pub-6695207583571149~6442750229`
  - Banner: `ca-app-pub-6695207583571149/4336385072`
  - Interstitial: `ca-app-pub-6695207583571149/1122055063`
  - Rewarded: `ca-app-pub-6695207583571149/6578481594`

### Ad Placement & Policy Compliance
1. **Adaptive Banner**:
   - Pinned outside active gameplay at the bottom of the screen.
   - Automatically hidden during active runs via `hideBanner()` to prevent covering game objects or touch controls.
   - Visible in Menu, Shop, and Game Over screens via `showBanner()`.
2. **Interstitial Ad**:
   - Shown strictly between runs (every 3 completed runs, with a 60-second cooldown).
   - Never shown during active gameplay, pause, or transitions.
3. **Rewarded Revive**:
   - Limit: strictly 1 revive per run.
   - Reward is verified exclusively through the native SDK's `onUserEarnedReward` callback before dispatching `ad_reward_granted` to JavaScript.
   - Safe error handling if ad is closed early or network drops.
