// Neon Flip - Player & Physics Engine

class NeonRunner {
    constructor(config) {
        this.config = config;
        this.reset();
    }

    reset() {
        this.radius = this.config.physics.playerRadius;
        this.x = 100;
        this.floorY = this.config.physics.floorY;
        this.ceilingY = this.config.physics.ceilingY;

        this.gravityDir = 1; // 1 = Floor, -1 = Ceiling
        this.y = this.floorY - this.radius;
        this.targetY = this.y;
        this.vy = 0;
        this.isFlipping = false;
        this.flipProgress = 0;
        this.rotation = 0;
        this.targetRotation = 0;

        // Trail & visual particles
        this.trail = [];
        this.maxTrail = this.config.physics.trailLength;
        this.particles = [];

        // Active Powerups
        this.hasShield = false;
        this.shieldDuration = 0;
        this.magnetDuration = 0;
        this.multiplierDuration = 0;
        this.invulnerableTimer = 0;

        // Equip active skin
        this.skin = (window.neonProfile && window.neonProfile.getSelectedSkin()) || this.config.skins[0];
    }

    applySkin(skin) {
        this.skin = skin;
    }

    flip() {
        this.gravityDir = -this.gravityDir;
        this.isFlipping = true;
        this.flipProgress = 0;

        const targetSurfaceY = (this.gravityDir === 1) ? this.floorY : this.ceilingY;
        this.targetY = targetSurfaceY - (this.gravityDir * this.radius);

        // Spin 180 degrees in flip direction
        this.targetRotation += Math.PI * this.gravityDir;

        // Emit flip impulse sparks
        this.emitParticles(8, this.skin.primaryColor);

        // Haptic feedback & sound
        if (window.NeonFlipAdBridge) window.NeonFlipAdBridge.haptic("flip");
        if (window.neonAudio) window.neonAudio.playFlip();
    }

    update(dt) {
        // Invulnerability countdown
        if (this.invulnerableTimer > 0) {
            this.invulnerableTimer -= dt;
        }

        // Power-up durations
        if (this.shieldDuration > 0) {
            this.shieldDuration -= dt;
            if (this.shieldDuration <= 0) this.hasShield = false;
        }
        if (this.magnetDuration > 0) {
            this.magnetDuration -= dt;
        }
        if (this.multiplierDuration > 0) {
            this.multiplierDuration -= dt;
        }

        // Smooth physics interpolation for gravity flip
        if (this.isFlipping) {
            this.flipProgress += dt / this.config.physics.flipDuration;
            if (this.flipProgress >= 1) {
                this.flipProgress = 1;
                this.y = this.targetY;
                this.isFlipping = false;
                this.rotation = this.targetRotation;
                // Landing sparks
                this.emitParticles(5, this.skin.secondaryColor);
            } else {
                // EaseInOutCubic transition for smooth mechanical feel
                const t = this.flipProgress;
                const ease = t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
                const startY = (this.gravityDir === 1) ? (this.ceilingY + this.radius) : (this.floorY - this.radius);
                this.y = startY + (this.targetY - startY) * ease;
                this.rotation += (this.targetRotation - this.rotation) * 0.25;
            }
        } else {
            this.y = this.targetY;
            this.rotation += (this.targetRotation - this.rotation) * 0.3;
        }

        // Record motion trail
        this.trail.unshift({
            x: this.x,
            y: this.y,
            rotation: this.rotation,
            alpha: 1.0,
            scale: 1.0
        });
        if (this.trail.length > this.maxTrail) {
            this.trail.pop();
        }

        // Fade trail
        for (let i = 0; i < this.trail.length; i++) {
            this.trail[i].alpha = 1 - (i / this.maxTrail);
            this.trail[i].scale = 1 - (i / (this.maxTrail * 1.5));
        }

        // Update particles
        for (let i = this.particles.length - 1; i >= 0; i--) {
            const p = this.particles[i];
            p.x += p.vx * dt;
            p.y += p.vy * dt;
            p.life -= dt;
            p.alpha = Math.max(0, p.life / p.maxLife);
            if (p.life <= 0) {
                this.particles.splice(i, 1);
            }
        }
    }

    emitParticles(count, color) {
        for (let i = 0; i < count; i++) {
            const angle = Math.random() * Math.PI * 2;
            const speed = 60 + Math.random() * 180;
            this.particles.push({
                x: this.x + (Math.random() - 0.5) * 10,
                y: this.y + (Math.random() - 0.5) * 10,
                vx: Math.cos(angle) * speed,
                vy: Math.sin(angle) * speed,
                size: 2 + Math.random() * 3.5,
                color: color || this.skin.primaryColor,
                life: 0.2 + Math.random() * 0.3,
                maxLife: 0.4,
                alpha: 1.0
            });
        }
    }

    activateShield(duration = 7) {
        this.hasShield = true;
        this.shieldDuration = duration;
        this.emitParticles(20, this.config.themeColors.shield);
        if (window.neonAudio) window.neonAudio.playShield();
        if (window.NeonFlipAdBridge) window.NeonFlipAdBridge.haptic("shield");
    }

    activateMagnet(duration = 8) {
        this.magnetDuration = duration;
        this.emitParticles(15, this.config.themeColors.magnet);
        if (window.NeonFlipAdBridge) window.NeonFlipAdBridge.haptic("powerup");
    }

    activateMultiplier(duration = 10) {
        this.multiplierDuration = duration;
        this.emitParticles(15, this.config.themeColors.multiplier);
        if (window.NeonFlipAdBridge) window.NeonFlipAdBridge.haptic("powerup");
    }

    revive() {
        // Place player safely in the middle and grant temporary invulnerability
        this.isFlipping = false;
        this.gravityDir = 1;
        this.y = this.floorY - this.radius;
        this.targetY = this.y;
        this.invulnerableTimer = 3.5;
        this.activateShield(3.5);
        this.emitParticles(30, "#00f0ff");
        if (window.neonAudio) window.neonAudio.playRevive();
        if (window.NeonFlipAdBridge) window.NeonFlipAdBridge.haptic("success");
    }

    // Circular hit testing
    checkCollisionWith(obstacle) {
        if (this.invulnerableTimer > 0) return false;

        // Obstacle can be triangle (spike) or rectangle (laser gate) or circle (orb)
        if (obstacle.type === "spike") {
            // Triangle hitbox
            return this.pointInTriangleCollision(obstacle);
        } else if (obstacle.type === "laser") {
            // Laser beam box
            if (!obstacle.active) return false;
            return this.circleRectCollision(obstacle.x, obstacle.y, obstacle.width, obstacle.height);
        } else if (obstacle.type === "orb") {
            // Circle vs circle
            const dx = this.x - obstacle.x;
            const dy = this.y - obstacle.y;
            const dist = Math.sqrt(dx * dx + dy * dy);
            return dist < (this.radius + obstacle.radius * 0.85);
        }
        return false;
    }

    circleRectCollision(rx, ry, rw, rh) {
        const closestX = Math.max(rx, Math.min(this.x, rx + rw));
        const closestY = Math.max(ry, Math.min(this.y, ry + rh));
        const dx = this.x - closestX;
        const dy = this.y - closestY;
        return (dx * dx + dy * dy) < (this.radius * this.radius * 0.85);
    }

    pointInTriangleCollision(spike) {
        // Check circle collision with spike peak and base
        const dx = this.x - spike.tipX;
        const dy = this.y - spike.tipY;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < this.radius * 0.9) return true;

        // Check if player is within spike width
        const withinX = this.x > (spike.x - this.radius * 0.7) && this.x < (spike.x + spike.width + this.radius * 0.7);
        if (withinX) {
            if (spike.isCeiling) {
                return (this.y - this.radius) < spike.baseY;
            } else {
                return (this.y + this.radius) > spike.baseY;
            }
        }
        return false;
    }
}

if (typeof module !== "undefined" && module.exports) {
    module.exports = NeonRunner;
}
