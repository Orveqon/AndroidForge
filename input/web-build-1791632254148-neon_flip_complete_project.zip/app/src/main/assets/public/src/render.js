// Neon Flip - Canvas 2D Neon Renderer

class NeonRenderer {
    constructor(ctx, config) {
        this.ctx = ctx;
        this.config = config;
        this.gridOffset = 0;
        this.speedLines = [];
        this.floatingTexts = [];
        this.shakeTime = 0;
        this.shakeAmount = 0;

        this.initSpeedLines();
    }

    initSpeedLines() {
        this.speedLines = [];
        for (let i = 0; i < 25; i++) {
            this.speedLines.push({
                x: Math.random() * this.config.baseCanvasWidth,
                y: 120 + Math.random() * (this.config.physics.floorY - 120),
                length: 40 + Math.random() * 90,
                speed: 1.2 + Math.random() * 1.5,
                alpha: 0.15 + Math.random() * 0.35
            });
        }
    }

    addShake(intensity = 6, duration = 0.25) {
        if (!window.neonProfile || !window.neonProfile.getSetting("screenShake")) return;
        this.shakeAmount = Math.min(this.config.physics.shakeIntensityMax, intensity);
        this.shakeTime = duration;
    }

    addFloatingText(text, x, y, color = "#00f0ff") {
        this.floatingTexts.push({
            text,
            x,
            y,
            vy: -45,
            color,
            life: 0.8,
            maxLife: 0.8,
            alpha: 1.0
        });
    }

    update(dt, speed) {
        // Scroll grid
        this.gridOffset = (this.gridOffset + speed * dt) % 60;

        // Update speed lines
        for (const line of this.speedLines) {
            line.x -= speed * line.speed * dt;
            if (line.x + line.length < 0) {
                line.x = this.config.baseCanvasWidth + Math.random() * 100;
                line.y = 130 + Math.random() * (this.config.physics.floorY - 150);
            }
        }

        // Update floating texts
        for (let i = this.floatingTexts.length - 1; i >= 0; i--) {
            const ft = this.floatingTexts[i];
            ft.y += ft.vy * dt;
            ft.life -= dt;
            ft.alpha = Math.max(0, ft.life / ft.maxLife);
            if (ft.life <= 0) {
                this.floatingTexts.splice(i, 1);
            }
        }

        // Shake timer
        if (this.shakeTime > 0) {
            this.shakeTime -= dt;
        } else {
            this.shakeAmount = 0;
        }
    }

    render(runner, obstacles, sparks, powerups, score, multiplier, isPlaying) {
        const ctx = this.ctx;
        const w = this.config.baseCanvasWidth;
        const h = this.config.baseCanvasHeight;

        ctx.save();

        // Apply screen shake
        if (this.shakeAmount > 0) {
            const sx = (Math.random() - 0.5) * this.shakeAmount * 2;
            const sy = (Math.random() - 0.5) * this.shakeAmount * 2;
            ctx.translate(sx, sy);
        }

        // 1. Deep Space Neon Background
        ctx.fillStyle = this.config.themeColors.bgDeep;
        ctx.fillRect(0, 0, w, h);

        // 2. Perspective Background Grid
        this.drawBackgroundGrid(w, h);

        // 3. Motion Speed Lines
        if (isPlaying) {
            this.drawSpeedLines();
        }

        // 4. Rails (Floor & Ceiling)
        this.drawRails(w);

        // 5. Obstacles
        this.drawObstacles(obstacles);

        // 6. Sparks & Powerups
        this.drawSparks(sparks);
        this.drawPowerups(powerups);

        // 7. Player Runner & Trails
        this.drawRunner(runner);

        // 8. Floating Texts
        this.drawFloatingTexts();

        ctx.restore();
    }

    drawBackgroundGrid(w, h) {
        const ctx = this.ctx;
        ctx.save();
        ctx.strokeStyle = "rgba(0, 240, 255, 0.05)";
        ctx.lineWidth = 1;

        // Vertical lines
        const step = 60;
        const startX = -this.gridOffset;
        for (let x = startX; x <= w + step; x += step) {
            ctx.beginPath();
            ctx.moveTo(x, 0);
            ctx.lineTo(x, h);
            ctx.stroke();
        }

        // Horizontal lines
        for (let y = 0; y <= h; y += step) {
            ctx.beginPath();
            ctx.moveTo(0, y);
            ctx.lineTo(w, y);
            ctx.stroke();
        }

        ctx.restore();
    }

    drawSpeedLines() {
        const ctx = this.ctx;
        ctx.save();
        for (const line of this.speedLines) {
            ctx.strokeStyle = `rgba(0, 240, 255, ${line.alpha})`;
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.moveTo(line.x, line.y);
            ctx.lineTo(line.x + line.length, line.y);
            ctx.stroke();
        }
        ctx.restore();
    }

    drawRails(w) {
        const ctx = this.ctx;
        const floorY = this.config.physics.floorY;
        const ceilingY = this.config.physics.ceilingY;

        ctx.save();

        // Glowing Ceiling Rail
        ctx.strokeStyle = "#00f0ff";
        ctx.shadowColor = "#00f0ff";
        ctx.shadowBlur = 12;
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.moveTo(0, ceilingY);
        ctx.lineTo(w, ceilingY);
        ctx.stroke();

        // Ceiling rail top barrier fill
        ctx.fillStyle = "rgba(0, 240, 255, 0.08)";
        ctx.fillRect(0, 0, w, ceilingY);

        // Glowing Floor Rail
        ctx.strokeStyle = "#ff0077";
        ctx.shadowColor = "#ff0077";
        ctx.shadowBlur = 12;
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.moveTo(0, floorY);
        ctx.lineTo(w, floorY);
        ctx.stroke();

        // Floor rail bottom barrier fill
        ctx.fillStyle = "rgba(255, 0, 119, 0.08)";
        ctx.fillRect(0, floorY, w, this.config.baseCanvasHeight - floorY);

        ctx.restore();
    }

    drawRunner(runner) {
        const ctx = this.ctx;
        const skin = runner.skin;

        ctx.save();

        // 1. Draw motion blur trails
        for (let i = runner.trail.length - 1; i >= 0; i--) {
            const node = runner.trail[i];
            ctx.save();
            ctx.translate(node.x, node.y);
            ctx.rotate(node.rotation);
            ctx.globalAlpha = node.alpha * 0.45;
            this.drawPlayerShape(ctx, runner.radius * node.scale, skin, true);
            ctx.restore();
        }

        // 2. Draw runner particles
        for (const p of runner.particles) {
            ctx.save();
            ctx.globalAlpha = p.alpha;
            ctx.fillStyle = p.color;
            ctx.shadowColor = p.color;
            ctx.shadowBlur = 8;
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();
        }

        // 3. Draw player main body
        ctx.save();
        ctx.translate(runner.x, runner.y);
        ctx.rotate(runner.rotation);

        // Invulnerable flash
        if (runner.invulnerableTimer > 0 && Math.floor(runner.invulnerableTimer * 12) % 2 === 0) {
            ctx.globalAlpha = 0.4;
        }

        this.drawPlayerShape(ctx, runner.radius, skin, false);

        // 4. Power-up Auras
        if (runner.hasShield) {
            this.drawShieldAura(ctx, runner.radius);
        }
        if (runner.magnetDuration > 0) {
            this.drawMagnetAura(ctx, runner.radius);
        }

        ctx.restore();
        ctx.restore();
    }

    drawPlayerShape(ctx, radius, skin, isTrail = false) {
        ctx.save();
        ctx.shadowColor = skin.glowColor;
        ctx.shadowBlur = isTrail ? 6 : 16;

        ctx.fillStyle = isTrail ? skin.secondaryColor : skin.primaryColor;
        ctx.strokeStyle = "#ffffff";
        ctx.lineWidth = isTrail ? 1.5 : 2.5;

        const size = radius * 1.8;

        switch (skin.shape) {
            case "cube":
            default:
                ctx.fillRect(-size / 2, -size / 2, size, size);
                ctx.strokeRect(-size / 2, -size / 2, size, size);
                // Inner core accent
                if (!isTrail) {
                    ctx.fillStyle = skin.secondaryColor;
                    ctx.fillRect(-size / 4, -size / 4, size / 2, size / 2);
                }
                break;

            case "rhombus":
            case "diamond":
                ctx.beginPath();
                ctx.moveTo(0, -size);
                ctx.lineTo(size * 0.8, 0);
                ctx.lineTo(0, size);
                ctx.lineTo(-size * 0.8, 0);
                ctx.closePath();
                ctx.fill();
                ctx.stroke();
                break;

            case "hexagon":
                ctx.beginPath();
                for (let i = 0; i < 6; i++) {
                    const angle = (i * Math.PI) / 3;
                    const hx = Math.cos(angle) * size * 0.65;
                    const hy = Math.sin(angle) * size * 0.65;
                    if (i === 0) ctx.moveTo(hx, hy);
                    else ctx.lineTo(hx, hy);
                }
                ctx.closePath();
                ctx.fill();
                ctx.stroke();
                break;

            case "octahedron":
            case "hypercube":
                ctx.beginPath();
                ctx.arc(0, 0, radius, 0, Math.PI * 2);
                ctx.fill();
                ctx.stroke();
                // Inner rotating cross
                if (!isTrail) {
                    ctx.strokeStyle = skin.secondaryColor;
                    ctx.lineWidth = 2;
                    ctx.beginPath();
                    ctx.moveTo(-radius * 0.7, 0);
                    ctx.lineTo(radius * 0.7, 0);
                    ctx.moveTo(0, -radius * 0.7);
                    ctx.lineTo(0, radius * 0.7);
                    ctx.stroke();
                }
                break;
        }

        ctx.restore();
    }

    drawShieldAura(ctx, radius) {
        ctx.save();
        ctx.strokeStyle = "#00e5ff";
        ctx.shadowColor = "#00e5ff";
        ctx.shadowBlur = 14;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(0, 0, radius * 1.65, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
    }

    drawMagnetAura(ctx, radius) {
        ctx.save();
        ctx.strokeStyle = "rgba(255, 145, 0, 0.6)";
        ctx.shadowColor = "#ff9100";
        ctx.shadowBlur = 10;
        ctx.lineWidth = 2;
        ctx.setLineDash([6, 6]);
        ctx.beginPath();
        ctx.arc(0, 0, radius * 2.1, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
    }

    drawObstacles(obstacles) {
        const ctx = this.ctx;
        ctx.save();

        for (const obs of obstacles) {
            if (obs.type === "spike") {
                this.drawSpike(ctx, obs);
            } else if (obs.type === "laser") {
                this.drawLaser(ctx, obs);
            } else if (obs.type === "orb") {
                this.drawOrb(ctx, obs);
            }
        }

        ctx.restore();
    }

    drawSpike(ctx, spike) {
        ctx.save();
        const color = spike.color || "#ff1744";
        ctx.shadowColor = color;
        ctx.shadowBlur = 14;
        ctx.fillStyle = color;
        ctx.strokeStyle = "#ffffff";
        ctx.lineWidth = 2;

        ctx.beginPath();
        ctx.moveTo(spike.x, spike.baseY);
        ctx.lineTo(spike.tipX, spike.tipY);
        ctx.lineTo(spike.x + spike.width, spike.baseY);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();

        // Inner core line
        ctx.strokeStyle = "rgba(255, 255, 255, 0.8)";
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(spike.x + spike.width / 2, spike.baseY);
        ctx.lineTo(spike.tipX, spike.tipY);
        ctx.stroke();

        ctx.restore();
    }

    drawLaser(ctx, laser) {
        ctx.save();
        const alpha = laser.active ? 0.9 : 0.2;
        ctx.strokeStyle = `rgba(255, 0, 119, ${alpha})`;
        ctx.fillStyle = `rgba(255, 0, 119, ${alpha * 0.6})`;
        ctx.shadowColor = "#ff0077";
        ctx.shadowBlur = laser.active ? 16 : 4;

        ctx.fillRect(laser.x, laser.y, laser.width, laser.height);
        ctx.strokeRect(laser.x, laser.y, laser.width, laser.height);

        // Laser core beam
        if (laser.active) {
            ctx.fillStyle = "#ffffff";
            ctx.fillRect(laser.x + laser.width * 0.35, laser.y, laser.width * 0.3, laser.height);
        }

        ctx.restore();
    }

    drawOrb(ctx, orb) {
        ctx.save();
        ctx.fillStyle = orb.color || "#ffe600";
        ctx.strokeStyle = "#ffffff";
        ctx.shadowColor = orb.color || "#ffe600";
        ctx.shadowBlur = 16;
        ctx.lineWidth = 2.5;

        ctx.beginPath();
        ctx.arc(orb.x, orb.y, orb.radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();

        ctx.restore();
    }

    drawSparks(sparks) {
        const ctx = this.ctx;
        ctx.save();

        for (const s of sparks) {
            ctx.save();
            ctx.translate(s.x, s.y);
            ctx.rotate(s.rotation);
            ctx.fillStyle = s.color || "#ffe600";
            ctx.strokeStyle = "#ffffff";
            ctx.shadowColor = s.color || "#ffe600";
            ctx.shadowBlur = 12;
            ctx.lineWidth = 1.5;

            // Diamond spark
            ctx.beginPath();
            ctx.moveTo(0, -s.radius);
            ctx.lineTo(s.radius * 0.7, 0);
            ctx.lineTo(0, s.radius);
            ctx.lineTo(-s.radius * 0.7, 0);
            ctx.closePath();
            ctx.fill();
            ctx.stroke();

            ctx.restore();
        }

        ctx.restore();
    }

    drawPowerups(powerups) {
        const ctx = this.ctx;
        ctx.save();

        for (const p of powerups) {
            ctx.save();
            ctx.translate(p.x, p.y);
            ctx.fillStyle = p.color;
            ctx.strokeStyle = "#ffffff";
            ctx.shadowColor = p.color;
            ctx.shadowBlur = 18;
            ctx.lineWidth = 2.5;

            // Hexagon container
            ctx.beginPath();
            for (let i = 0; i < 6; i++) {
                const angle = (i * Math.PI) / 3;
                const hx = Math.cos(angle) * p.radius;
                const hy = Math.sin(angle) * p.radius;
                if (i === 0) ctx.moveTo(hx, hy);
                else ctx.lineTo(hx, hy);
            }
            ctx.closePath();
            ctx.fill();
            ctx.stroke();

            // Icon label
            ctx.fillStyle = "#ffffff";
            ctx.font = "bold 13px sans-serif";
            ctx.textAlign = "center";
            ctx.textBaseline = "middle";
            ctx.fillText(p.label, 0, 0);

            ctx.restore();
        }

        ctx.restore();
    }

    drawFloatingTexts() {
        const ctx = this.ctx;
        ctx.save();
        for (const ft of this.floatingTexts) {
            ctx.font = "bold 18px sans-serif";
            ctx.textAlign = "center";
            ctx.fillStyle = ft.color;
            ctx.shadowColor = ft.color;
            ctx.shadowBlur = 10;
            ctx.globalAlpha = ft.alpha;
            ctx.fillText(ft.text, ft.x, ft.y);
        }
        ctx.restore();
    }
}

if (typeof module !== "undefined" && module.exports) {
    module.exports = NeonRenderer;
}
