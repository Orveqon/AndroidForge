// Neon Flip - Game Configuration
const NEON_CONFIG = {
    version: "2.1.0",
    storageKey: "neon_flip_save_data_v2",

    // Visuals & Display
    targetFps: 60,
    baseCanvasWidth: 480,
    baseCanvasHeight: 800,
    themeColors: {
        bgDeep: "#0a0a1a",
        bgGrid: "rgba(0, 240, 255, 0.08)",
        cyan: "#00f0ff",
        magenta: "#ff0077",
        yellow: "#ffe600",
        green: "#00ff66",
        purple: "#9d00ff",
        white: "#ffffff",
        danger: "#ff1744",
        shield: "#00e5ff",
        magnet: "#ff9100",
        multiplier: "#d500f9"
    },

    // Game Physics & Difficulty Progression
    physics: {
        baseSpeed: 380,           // Starting horizontal travel speed (pixels/sec)
        maxSpeed: 750,            // Speed cap for fair, high-reflex challenge
        speedRampRate: 4.5,       // Speed increment per second
        flipDuration: 0.18,       // Seconds taken to transition between floor & ceiling
        playerRadius: 18,         // Hitbox radius
        trailLength: 14,          // Number of trail nodes
        floorY: 680,              // Default bottom boundary (adjusted by viewport)
        ceilingY: 120,            // Default top boundary
        obstacleSpacingMin: 220,  // Minimum gap between hazard pairs
        sparkSpawnRate: 0.75,     // Chance of sparks between obstacles
        shakeIntensityMax: 12,    // Maximum screen shake in pixels
    },

    // Ad Placement & Logic
    ads: {
        runsBetweenInterstitials: 3,
        interstitialCooldownSeconds: 60,
        maxRevivesPerRun: 1,
        rewardedSparksBonus: 100,
        bannerSafeBottomPadding: 56 // Safe area padding when banner is visible
    },

    // Unlockable Neon Skins
    skins: [
        {
            id: "skin_cyan_pulse",
            name: "Cyan Pulse",
            desc: "The iconic cyber pioneer with classic dual cyan glow.",
            cost: 0,
            primaryColor: "#00f0ff",
            secondaryColor: "#0077ff",
            glowColor: "rgba(0, 240, 255, 0.8)",
            trailStyle: "spark",
            shape: "cube"
        },
        {
            id: "skin_magenta_matrix",
            name: "Magenta Matrix",
            desc: "Infused with hot neon synth energy and hyper-reactive trails.",
            cost: 150,
            primaryColor: "#ff0077",
            secondaryColor: "#ff5500",
            glowColor: "rgba(255, 0, 119, 0.8)",
            trailStyle: "plasma",
            shape: "rhombus"
        },
        {
            id: "skin_solar_flare",
            name: "Solar Flare",
            desc: "Blazing golden overdrive with radiant orbital sparks.",
            cost: 350,
            primaryColor: "#ffe600",
            secondaryColor: "#ff9100",
            glowColor: "rgba(255, 230, 0, 0.85)",
            trailStyle: "solar",
            shape: "hexagon"
        },
        {
            id: "skin_emerald_grid",
            name: "Emerald Grid",
            desc: "Quantum velocity runner with electric lime refraction.",
            cost: 600,
            primaryColor: "#00ff66",
            secondaryColor: "#00b0ff",
            glowColor: "rgba(0, 255, 102, 0.8)",
            trailStyle: "grid",
            shape: "diamond"
        },
        {
            id: "skin_void_purple",
            name: "Void Core",
            desc: "Dark matter cyber-crystal with ultra-violet neon bloom.",
            cost: 1000,
            primaryColor: "#d500f9",
            secondaryColor: "#651fff",
            glowColor: "rgba(213, 0, 249, 0.85)",
            trailStyle: "void",
            shape: "octahedron"
        },
        {
            id: "skin_rainbow_overdrive",
            name: "Rainbow Overdrive",
            desc: "Living spectrum shifting through every frequency of light.",
            cost: 2000,
            primaryColor: "#00f0ff",
            secondaryColor: "#ff0077",
            glowColor: "rgba(255, 255, 255, 0.9)",
            trailStyle: "rainbow",
            shape: "hypercube"
        }
    ],

    // Upgrades
    upgrades: [
        {
            id: "upgrade_shield",
            name: "Energy Shield",
            desc: "Absorbs 1 hazard collision during run",
            cost: 200,
            maxLevel: 3,
            costPerLevel: 250,
            baseDuration: 6.0,
            durationPerLevel: 2.0
        },
        {
            id: "upgrade_magnet",
            name: "Spark Magnet",
            desc: "Pulls nearby neon sparks automatically",
            cost: 150,
            maxLevel: 3,
            costPerLevel: 200,
            baseDuration: 8.0,
            durationPerLevel: 3.0
        },
        {
            id: "upgrade_multiplier",
            name: "Double Sparks",
            desc: "Doubles spark value for a limited time",
            cost: 300,
            maxLevel: 3,
            costPerLevel: 350,
            baseDuration: 10.0,
            durationPerLevel: 4.0
        }
    ]
};

if (typeof module !== "undefined" && module.exports) {
    module.exports = NEON_CONFIG;
}
