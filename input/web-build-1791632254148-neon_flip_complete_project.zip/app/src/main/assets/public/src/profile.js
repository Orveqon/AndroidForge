// Neon Flip - Profile & Persistence Management

class NeonProfileManager {
    constructor() {
        this.storageKey = NEON_CONFIG.storageKey;
        this.data = this.getDefaultProfile();
        this.load();
    }

    getDefaultProfile() {
        return {
            version: NEON_CONFIG.version,
            sparks: 50, // Starting gift sparks
            highScore: 0,
            bestRunDistance: 0,
            runsCompleted: 0,
            selectedSkin: "skin_cyan_pulse",
            unlockedSkins: ["skin_cyan_pulse"],
            upgrades: {
                upgrade_shield: 0,
                upgrade_magnet: 0,
                upgrade_multiplier: 0
            },
            settings: {
                sound: true,
                music: true,
                haptics: true,
                screenShake: true
            },
            adStats: {
                interstitialsShown: 0,
                revivesUsed: 0,
                rewardedSparksClaimed: 0
            }
        };
    }

    load() {
        try {
            const raw = localStorage.getItem(this.storageKey);
            if (raw) {
                const parsed = JSON.parse(raw);
                this.data = Object.assign(this.getDefaultProfile(), parsed);
                // Ensure arrays & objects exist
                if (!Array.isArray(this.data.unlockedSkins)) {
                    this.data.unlockedSkins = ["skin_cyan_pulse"];
                }
                if (!this.data.unlockedSkins.includes("skin_cyan_pulse")) {
                    this.data.unlockedSkins.push("skin_cyan_pulse");
                }
                if (!this.data.upgrades) {
                    this.data.upgrades = { upgrade_shield: 0, upgrade_magnet: 0, upgrade_multiplier: 0 };
                }
            } else {
                this.save();
            }
        } catch (e) {
            console.warn("Storage load error, using default profile:", e);
            this.data = this.getDefaultProfile();
        }
    }

    save() {
        try {
            localStorage.setItem(this.storageKey, JSON.stringify(this.data));
        } catch (e) {
            console.warn("Storage save error:", e);
        }
    }

    // --- Currency & Progression ---

    getSparks() {
        return this.data.sparks || 0;
    }

    addSparks(amount) {
        if (amount <= 0) return;
        this.data.sparks = (this.data.sparks || 0) + amount;
        this.save();
        return this.data.sparks;
    }

    spendSparks(amount) {
        if (this.data.sparks < amount) return false;
        this.data.sparks -= amount;
        this.save();
        return true;
    }

    getHighScore() {
        return this.data.highScore || 0;
    }

    setScore(score, distance) {
        let isNewHigh = false;
        if (score > (this.data.highScore || 0)) {
            this.data.highScore = score;
            isNewHigh = true;
        }
        if (distance > (this.data.bestRunDistance || 0)) {
            this.data.bestRunDistance = Math.floor(distance);
        }
        this.data.runsCompleted = (this.data.runsCompleted || 0) + 1;
        this.save();
        return isNewHigh;
    }

    getRunsCompleted() {
        return this.data.runsCompleted || 0;
    }

    // --- Skins ---

    getSelectedSkin() {
        const skinId = this.data.selectedSkin || "skin_cyan_pulse";
        return NEON_CONFIG.skins.find(s => s.id === skinId) || NEON_CONFIG.skins[0];
    }

    isSkinUnlocked(skinId) {
        return this.data.unlockedSkins.includes(skinId);
    }

    unlockSkin(skinId) {
        const skin = NEON_CONFIG.skins.find(s => s.id === skinId);
        if (!skin) return false;
        if (this.isSkinUnlocked(skinId)) return true;

        if (this.spendSparks(skin.cost)) {
            this.data.unlockedSkins.push(skinId);
            this.equipSkin(skinId);
            this.save();
            return true;
        }
        return false;
    }

    equipSkin(skinId) {
        if (this.isSkinUnlocked(skinId)) {
            this.data.selectedSkin = skinId;
            this.save();
            return true;
        }
        return false;
    }

    // --- Upgrades ---

    getUpgradeLevel(upgradeId) {
        return this.data.upgrades[upgradeId] || 0;
    }

    getUpgradeCost(upgradeId) {
        const item = NEON_CONFIG.upgrades.find(u => u.id === upgradeId);
        if (!item) return Infinity;
        const currentLvl = this.getUpgradeLevel(upgradeId);
        if (currentLvl >= item.maxLevel) return -1; // Maxed out
        return item.cost + currentLvl * item.costPerLevel;
    }

    buyUpgrade(upgradeId) {
        const cost = this.getUpgradeCost(upgradeId);
        if (cost <= 0 || cost > this.data.sparks) return false;

        if (this.spendSparks(cost)) {
            this.data.upgrades[upgradeId] = (this.data.upgrades[upgradeId] || 0) + 1;
            this.save();
            return true;
        }
        return false;
    }

    getUpgradeDuration(upgradeId) {
        const item = NEON_CONFIG.upgrades.find(u => u.id === upgradeId);
        if (!item) return 5;
        const level = this.getUpgradeLevel(upgradeId);
        return item.baseDuration + level * item.durationPerLevel;
    }

    // --- Settings ---

    getSetting(key) {
        return this.data.settings[key] ?? true;
    }

    setSetting(key, val) {
        this.data.settings[key] = val;
        this.save();
        if (key === "sound" && window.neonAudio) {
            window.neonAudio.setSoundEnabled(val);
        }
        if (key === "music" && window.neonAudio) {
            window.neonAudio.setMusicEnabled(val);
        }
    }
}

window.neonProfile = new NeonProfileManager();
