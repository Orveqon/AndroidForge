// Neon Flip - Procedural Web Audio Synthesizer
// Provides punchy, low-latency cyber arcade sound effects and synthwave music without external assets.

class NeonAudioEngine {
    constructor() {
        this.ctx = null;
        this.soundEnabled = true;
        this.musicEnabled = true;
        this.masterVolume = 0.8;
        this.sfxGain = null;
        this.musicGain = null;
        this.musicInterval = null;
        this.musicStep = 0;
        this.isMuted = false;
    }

    init() {
        if (this.ctx) return;
        try {
            const AudioContextClass = window.AudioContext || window.webkitAudioContext;
            if (!AudioContextClass) return;
            this.ctx = new AudioContextClass();

            this.sfxGain = this.ctx.createGain();
            this.sfxGain.gain.setValueAtTime(this.soundEnabled ? 0.7 : 0, this.ctx.currentTime);
            this.sfxGain.connect(this.ctx.destination);

            this.musicGain = this.ctx.createGain();
            this.musicGain.gain.setValueAtTime(this.musicEnabled ? 0.35 : 0, this.ctx.currentTime);
            this.musicGain.connect(this.ctx.destination);

            if (this.musicEnabled) {
                this.startMusic();
            }
        } catch (e) {
            console.warn("AudioContext init error:", e);
        }
    }

    ensureContext() {
        if (!this.ctx) {
            this.init();
        } else if (this.ctx.state === "suspended") {
            this.ctx.resume().catch(() => {});
        }
    }

    setSoundEnabled(enabled) {
        this.soundEnabled = enabled;
        if (this.sfxGain && this.ctx) {
            this.sfxGain.gain.setValueAtTime(enabled ? 0.7 : 0, this.ctx.currentTime);
        }
    }

    setMusicEnabled(enabled) {
        this.musicEnabled = enabled;
        if (this.musicGain && this.ctx) {
            this.musicGain.gain.setValueAtTime(enabled ? 0.35 : 0, this.ctx.currentTime);
        }
        if (enabled) {
            this.startMusic();
        } else {
            this.stopMusic();
        }
    }

    // --- Sound Effects ---

    playFlip() {
        if (!this.soundEnabled) return;
        this.ensureContext();
        if (!this.ctx || !this.sfxGain) return;

        try {
            const t = this.ctx.currentTime;
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();

            osc.type = "sine";
            osc.frequency.setValueAtTime(320, t);
            osc.frequency.exponentialRampToValueAtTime(780, t + 0.12);

            gain.gain.setValueAtTime(0.5, t);
            gain.gain.exponentialRampToValueAtTime(0.001, t + 0.14);

            osc.connect(gain);
            gain.connect(this.sfxGain);

            osc.start(t);
            osc.stop(t + 0.15);
        } catch (_) {}
    }

    playSpark() {
        if (!this.soundEnabled) return;
        this.ensureContext();
        if (!this.ctx || !this.sfxGain) return;

        try {
            const t = this.ctx.currentTime;
            const notes = [880, 1174, 1318];
            const freq = notes[Math.floor(Math.random() * notes.length)];

            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();

            osc.type = "triangle";
            osc.frequency.setValueAtTime(freq, t);
            osc.frequency.exponentialRampToValueAtTime(freq * 1.5, t + 0.08);

            gain.gain.setValueAtTime(0.4, t);
            gain.gain.exponentialRampToValueAtTime(0.001, t + 0.12);

            osc.connect(gain);
            gain.connect(this.sfxGain);

            osc.start(t);
            osc.stop(t + 0.13);
        } catch (_) {}
    }

    playShield() {
        if (!this.soundEnabled) return;
        this.ensureContext();
        if (!this.ctx || !this.sfxGain) return;

        try {
            const t = this.ctx.currentTime;
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();

            osc.type = "sawtooth";
            osc.frequency.setValueAtTime(220, t);
            osc.frequency.exponentialRampToValueAtTime(880, t + 0.25);

            gain.gain.setValueAtTime(0.3, t);
            gain.gain.linearRampToValueAtTime(0.001, t + 0.3);

            osc.connect(gain);
            gain.connect(this.sfxGain);

            osc.start(t);
            osc.stop(t + 0.3);
        } catch (_) {}
    }

    playShieldBreak() {
        if (!this.soundEnabled) return;
        this.ensureContext();
        if (!this.ctx || !this.sfxGain) return;

        try {
            const t = this.ctx.currentTime;
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();

            osc.type = "square";
            osc.frequency.setValueAtTime(600, t);
            osc.frequency.exponentialRampToValueAtTime(150, t + 0.18);

            gain.gain.setValueAtTime(0.45, t);
            gain.gain.linearRampToValueAtTime(0.001, t + 0.2);

            osc.connect(gain);
            gain.connect(this.sfxGain);

            osc.start(t);
            osc.stop(t + 0.2);
        } catch (_) {}
    }

    playCrash() {
        if (!this.soundEnabled) return;
        this.ensureContext();
        if (!this.ctx || !this.sfxGain) return;

        try {
            const t = this.ctx.currentTime;
            // Low rumble oscillator
            const osc = this.ctx.createOscillator();
            const oscGain = this.ctx.createGain();

            osc.type = "sawtooth";
            osc.frequency.setValueAtTime(160, t);
            osc.frequency.exponentialRampToValueAtTime(30, t + 0.35);

            oscGain.gain.setValueAtTime(0.6, t);
            oscGain.gain.exponentialRampToValueAtTime(0.001, t + 0.4);

            osc.connect(oscGain);
            oscGain.connect(this.sfxGain);

            osc.start(t);
            osc.stop(t + 0.42);

            // White noise burst
            const bufferSize = this.ctx.sampleRate * 0.25;
            const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
            const output = noiseBuffer.getChannelData(0);
            for (let i = 0; i < bufferSize; i++) {
                output[i] = Math.random() * 2 - 1;
            }

            const whiteNoise = this.ctx.createBufferSource();
            whiteNoise.buffer = noiseBuffer;

            const filter = this.ctx.createBiquadFilter();
            filter.type = "lowpass";
            filter.frequency.setValueAtTime(800, t);
            filter.frequency.exponentialRampToValueAtTime(100, t + 0.25);

            const noiseGain = this.ctx.createGain();
            noiseGain.gain.setValueAtTime(0.5, t);
            noiseGain.gain.exponentialRampToValueAtTime(0.001, t + 0.3);

            whiteNoise.connect(filter);
            filter.connect(noiseGain);
            noiseGain.connect(this.sfxGain);

            whiteNoise.start(t);
            whiteNoise.stop(t + 0.3);
        } catch (_) {}
    }

    playRevive() {
        if (!this.soundEnabled) return;
        this.ensureContext();
        if (!this.ctx || !this.sfxGain) return;

        try {
            const t = this.ctx.currentTime;
            const notes = [440, 554, 659, 880];
            notes.forEach((freq, idx) => {
                const start = t + idx * 0.08;
                const osc = this.ctx.createOscillator();
                const gain = this.ctx.createGain();

                osc.type = "sine";
                osc.frequency.setValueAtTime(freq, start);
                osc.frequency.exponentialRampToValueAtTime(freq * 1.25, start + 0.2);

                gain.gain.setValueAtTime(0.35, start);
                gain.gain.exponentialRampToValueAtTime(0.001, start + 0.25);

                osc.connect(gain);
                gain.connect(this.sfxGain);

                osc.start(start);
                osc.stop(start + 0.26);
            });
        } catch (_) {}
    }

    playClick() {
        if (!this.soundEnabled) return;
        this.ensureContext();
        if (!this.ctx || !this.sfxGain) return;

        try {
            const t = this.ctx.currentTime;
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();

            osc.type = "sine";
            osc.frequency.setValueAtTime(900, t);
            gain.gain.setValueAtTime(0.15, t);
            gain.gain.exponentialRampToValueAtTime(0.001, t + 0.04);

            osc.connect(gain);
            gain.connect(this.sfxGain);

            osc.start(t);
            osc.stop(t + 0.05);
        } catch (_) {}
    }

    // --- Procedural Synthwave Bassline ---

    startMusic() {
        if (this.musicInterval) return;
        if (!this.ctx) this.init();

        const bassNotes = [110, 110, 146.83, 130.81, 110, 110, 164.81, 146.83];
        this.musicStep = 0;

        this.musicInterval = setInterval(() => {
            if (!this.musicEnabled || !this.ctx || !this.musicGain) return;
            try {
                const t = this.ctx.currentTime;
                const note = bassNotes[this.musicStep % bassNotes.length];
                this.musicStep++;

                const osc = this.ctx.createOscillator();
                const gain = this.ctx.createGain();
                const filter = this.ctx.createBiquadFilter();

                osc.type = "sawtooth";
                osc.frequency.setValueAtTime(note, t);

                filter.type = "lowpass";
                filter.frequency.setValueAtTime(380, t);
                filter.frequency.exponentialRampToValueAtTime(140, t + 0.18);

                gain.gain.setValueAtTime(0.2, t);
                gain.gain.exponentialRampToValueAtTime(0.001, t + 0.2);

                osc.connect(filter);
                filter.connect(gain);
                gain.connect(this.musicGain);

                osc.start(t);
                osc.stop(t + 0.21);
            } catch (_) {}
        }, 220); // ~136 BPM eighth notes
    }

    stopMusic() {
        if (this.musicInterval) {
            clearInterval(this.musicInterval);
            this.musicInterval = null;
        }
    }
}

window.neonAudio = new NeonAudioEngine();
