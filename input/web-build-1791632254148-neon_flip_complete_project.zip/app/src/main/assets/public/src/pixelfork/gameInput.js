// Neon Flip - Unified Input Management

class GameInput {
    constructor(element) {
        this.element = element || window;
        this.isPointerDown = false;
        this.listeners = [];
        this.keysDown = new Set();

        this.setupEvents();
    }

    setupEvents() {
        const onDown = (e) => {
            // Prevent default zooming/scrolling on mobile canvas
            if (e.target.tagName === "CANVAS") {
                e.preventDefault();
            }
            this.isPointerDown = true;
            this.emit("flip_action", { type: "pointer" });
        };

        const onUp = () => {
            this.isPointerDown = false;
        };

        const onKeyDown = (e) => {
            if (e.code === "Space" || e.code === "ArrowUp" || e.code === "ArrowDown" || e.code === "KeyW" || e.code === "KeyS") {
                e.preventDefault();
                if (!this.keysDown.has(e.code)) {
                    this.keysDown.add(e.code);
                    this.emit("flip_action", { type: "key", code: e.code });
                }
            } else if (e.code === "Escape" || e.code === "KeyP") {
                this.emit("pause_action", {});
            }
        };

        const onKeyUp = (e) => {
            this.keysDown.delete(e.code);
        };

        this.element.addEventListener("pointerdown", onDown, { passive: false });
        window.addEventListener("pointerup", onUp);
        window.addEventListener("pointercancel", onUp);
        window.addEventListener("keydown", onKeyDown);
        window.addEventListener("keyup", onKeyUp);
    }

    on(action, callback) {
        this.listeners.push({ action, callback });
    }

    emit(action, data) {
        for (const l of this.listeners) {
            if (l.action === action) {
                try { l.callback(data); } catch(e) { console.error(e); }
            }
        }
    }
}

if (typeof module !== "undefined" && module.exports) {
    module.exports = GameInput;
}
