// Neon Flip - Core Game Loop & Orchestrator

class NeonFlipGame {
    constructor() {
        this.canvas = document.getElementById("game-canvas");
        this.ctx = this.canvas.getContext("2d");

        this.config = NEON_CONFIG;
        this.viewport = new GameViewport(this.canvas, this.config.baseCanvasWidth, this.config.baseCanvasHeight);
        this.input = new GameInput(this.canvas);
        this.runner = new NeonRunner(this.config);
        this.renderer = new NeonRenderer(this.ctx, this.config);
        this.ui = new NeonUIManager(this);

        this.state = "MENU"; // "MENU" | "PLAYING" | "PAUSED" | "GAME_OVER"
        this.lastTime = 0;
        this.speed = this.config.physics.baseSpeed;
        this.distance = 0;
        this.score = 0;
        this.sparksCollectedInRun = 0;
        this.multiplier = 1;

        // Run tracking for Ads
        this.currentRunId = "";
        this.reviveUsedInCurrentRun = false;
        this.sessionRunsCount = 0;
        this.lastInterstitialTimestamp = 0;

        // World entities
        this.obstacles = [];
        this.sparks = [];
        this.powerups = [];
        this.nextSpawnX = 600;

        this.setupInput();
        this.ui.showMenu();

        // Start animation loop
        requestAnimationFrame((t) => this.loop(t));
    }

    setupInput() {
        this.input.on("flip_action", () => {
            if (this.state === "PLAYING") {
                this.runner.flip();
            } else if (this.state === "MENU") {
                this.startRun();
            }
        });

        this.input.on("pause_action", () => {
            this.togglePause();
        });
    }

    startRun() {
        this.currentRunId = "run_" + Date.now();
        this.reviveUsedInCurrentRun = false;
        this.state = "PLAYING";
        this.speed = this.config.physics.baseSpeed;
        this.distance = 0;
        this.score = 0;
        this.sparksCollectedInRun = 0;
        this.multiplier = 1;

        this.obstacles = [];
        this.sparks = [];
        this.powerups = [];
        this.nextSpawnX = 600;

        this.runner.reset();
        this.runner.applySkin(window.neonProfile.getSelectedSkin());

        this.ui.showGameplay();
        this.ui.updateHud(0, 0, 1);
        if (window.neonAudio) window.neonAudio.ensureContext();
    }

    togglePause() {
        if (this.state === "PLAYING") {
            this.state = "PAUSED";
            this.ui.showPause();
        } else if (this.state === "PAUSED") {
            this.state = "PLAYING";
            this.ui.hidePause();
            this.lastTime = performance.now();
        }
    }

    pause() {
        if (this.state === "PLAYING") {
            this.state = "PAUSED";
            this.ui.showPause();
        }
    }

    resume() {
        if (this.state === "PAUSED") {
            this.lastTime = performance.now();
        }
    }

    handleBackPress() {
        if (this.state === "PLAYING") {
            this.togglePause();
            return "handled";
        } else if (this.state === "PAUSED" || this.state === "GAME_OVER") {
            this.ui.showMenu();
            return "handled";
        }
        return "default";
    }

    // --- Main Game Loop ---

    loop(timestamp) {
        if (!this.lastTime) this.lastTime = timestamp;
        let dt = (timestamp - this.lastTime) / 1000;
        this.lastTime = timestamp;

        // Cap dt to avoid large leaps when resuming or frame drops
        if (dt > 0.08) dt = 0.08;

        if (this.state === "PLAYING") {
            this.update(dt);
        }

        // Always render smoothly
        this.renderer.update(dt, this.state === "PLAYING" ? this.speed : 100);
        this.renderer.render(
            this.runner,
            this.obstacles,
            this.sparks,
            this.powerups,
            this.score,
            this.multiplier,
            this.state === "PLAYING"
        );

        requestAnimationFrame((t) => this.loop(t));
    }

    update(dt) {
        // 1. Difficulty & Speed Ramping
        this.speed = Math.min(
            this.config.physics.maxSpeed,
            this.speed + this.config.physics.speedRampRate * dt
        );

        this.distance += this.speed * dt;
        this.score = Math.floor(this.distance / 10) + (this.sparksCollectedInRun * 10);

        // Multiplier tracking
        this.multiplier = (this.runner.multiplierDuration > 0) ? 2 : 1;
        this.ui.updateHud(this.score, this.sparksCollectedInRun, this.multiplier);

        // 2. Update Runner
        this.runner.update(dt);

        // 3. Update Obstacles & Spawning
        this.updateObstacles(dt);

        // 4. Update Sparks & Powerups
        this.updateCollectibles(dt);

        // 5. Collision Check
        for (const obs of this.obstacles) {
            if (this.runner.checkCollisionWith(obs)) {
                if (this.runner.hasShield) {
                    // Shield absorbed collision!
                    this.runner.hasShield = false;
                    this.runner.shieldDuration = 0;
                    this.renderer.addShake(8, 0.25);
                    this.renderer.addFloatingText("SHIELD DEFLECT!", this.runner.x, this.runner.y - 25, "#00e5ff");
                    if (window.neonAudio) window.neonAudio.playShieldBreak();
                    if (window.NeonFlipAdBridge) window.NeonFlipAdBridge.haptic("shield");

                    // Remove or pass obstacle
                    obs.x = -100;
                } else {
                    this.triggerCrash();
                    break;
                }
            }
        }
    }

    triggerCrash() {
        this.state = "GAME_OVER";
        this.sessionRunsCount++;

        this.renderer.addShake(12, 0.4);
        if (window.neonAudio) window.neonAudio.playCrash();
        if (window.NeonFlipAdBridge) window.NeonFlipAdBridge.haptic("crash");

        // Save progress & currency
        window.neonProfile.addSparks(this.sparksCollectedInRun);
        const isNewBest = window.neonProfile.setScore(this.score, this.distance);

        const canRevive = !this.reviveUsedInCurrentRun;

        this.ui.showGameOver({
            score: this.score,
            sparksEarned: this.sparksCollectedInRun,
            isNewHighScore: isNewBest
        }, canRevive);
    }

    executeRevive() {
        this.reviveUsedInCurrentRun = true;
        this.state = "PLAYING";
        this.lastTime = performance.now();

        // Clear nearby hazards to give player breathing room
        this.obstacles = this.obstacles.filter(o => o.x > 380);

        this.runner.revive();
        this.ui.showGameplay();
    }

    onGameOverAction(action) {
        // Check Interstitial ad frequency (Every 3 runs + cooldown)
        const now = Date.now();
        const cooldownMs = NEON_CONFIG.ads.interstitialCooldownSeconds * 1000;
        const cooldownElapsed = (now - this.lastInterstitialTimestamp) >= cooldownMs;

        if (this.sessionRunsCount >= NEON_CONFIG.ads.runsBetweenInterstitials && cooldownElapsed) {
            this.sessionRunsCount = 0;
            this.lastInterstitialTimestamp = now;
            console.log("AdMob: Triggering interstitial ad after 3 completed runs");
            window.NeonFlipAdBridge.showInterstitial(this.currentRunId);
        }

        if (action === "restart") {
            this.startRun();
        } else {
            this.ui.showMenu();
        }
    }

    // --- Procedural Generation ---

    updateObstacles(dt) {
        // Move obstacles
        for (let i = this.obstacles.length - 1; i >= 0; i--) {
            const obs = this.obstacles[i];
            obs.x -= this.speed * dt;
            if (obs.tipX !== undefined) obs.tipX -= this.speed * dt;

            // Toggle laser gates if present
            if (obs.type === "laser") {
                obs.pulseTimer = (obs.pulseTimer || 0) + dt;
                if (obs.pulseTimer > 1.8) {
                    obs.active = !obs.active;
                    obs.pulseTimer = 0;
                }
            }

            if (obs.x + (obs.width || 40) < -60) {
                this.obstacles.splice(i, 1);
            }
        }

        // Spawn new obstacles ahead
        const canvasW = this.config.baseCanvasWidth;
        const floorY = this.config.physics.floorY;
        const ceilingY = this.config.physics.ceilingY;

        while (this.nextSpawnX < canvasW + 600) {
            const patternRoll = Math.random();
            const minSpacing = Math.max(180, this.config.physics.obstacleSpacingMin - (this.speed * 0.05));

            if (patternRoll < 0.38) {
                // 1. Single Floor Spike
                this.obstacles.push(this.createSpike(this.nextSpawnX, floorY, false));
                this.maybeSpawnSparks(this.nextSpawnX + 80, ceilingY + 30);
            } else if (patternRoll < 0.70) {
                // 2. Single Ceiling Spike
                this.obstacles.push(this.createSpike(this.nextSpawnX, ceilingY, true));
                this.maybeSpawnSparks(this.nextSpawnX + 80, floorY - 30);
            } else if (patternRoll < 0.88) {
                // 3. Alternating Hazard Rhythm (Floor then Ceiling with fair reaction gap)
                this.obstacles.push(this.createSpike(this.nextSpawnX, floorY, false));
                this.obstacles.push(this.createSpike(this.nextSpawnX + minSpacing * 0.9, ceilingY, true));
                this.maybeSpawnSparks(this.nextSpawnX + minSpacing * 0.45, (floorY + ceilingY) / 2);
            } else {
                // 4. Pulsing Laser Barrier Gate
                const laserH = (floorY - ceilingY) * 0.45;
                const isTop = Math.random() > 0.5;
                this.obstacles.push({
                    type: "laser",
                    x: this.nextSpawnX,
                    y: isTop ? ceilingY : floorY - laserH,
                    width: 22,
                    height: laserH,
                    active: true,
                    pulseTimer: 0
                });
            }

            // Chance to spawn power-up pod
            if (Math.random() < 0.08) {
                this.spawnPowerup(this.nextSpawnX + minSpacing * 0.6);
            }

            this.nextSpawnX += minSpacing + Math.random() * 80;
        }
    }

    createSpike(x, baseY, isCeiling) {
        const width = 36;
        const height = 44;
        const tipY = isCeiling ? baseY + height : baseY - height;
        return {
            type: "spike",
            x: x,
            width: width,
            baseY: baseY,
            tipX: x + width / 2,
            tipY: tipY,
            isCeiling: isCeiling,
            color: this.config.themeColors.danger
        };
    }

    maybeSpawnSparks(x, y) {
        if (Math.random() < this.config.physics.sparkSpawnRate) {
            this.sparks.push({
                x: x,
                y: y,
                radius: 9,
                rotation: 0,
                color: "#ffe600"
            });
        }
    }

    spawnPowerup(x) {
        const types = [
            { type: "shield", label: "🛡️", color: "#00e5ff" },
            { type: "magnet", label: "🧲", color: "#ff9100" },
            { type: "multiplier", label: "2X", color: "#d500f9" }
        ];
        const selected = types[Math.floor(Math.random() * types.length)];
        const floorY = this.config.physics.floorY;
        const ceilingY = this.config.physics.ceilingY;

        this.powerups.push({
            type: selected.type,
            label: selected.label,
            color: selected.color,
            x: x,
            y: (floorY + ceilingY) / 2 + (Math.random() - 0.5) * 80,
            radius: 16
        });
    }

    updateCollectibles(dt) {
        const runner = this.runner;
        const magnetActive = runner.magnetDuration > 0;
        const magnetRange = 160;

        // 1. Sparks
        for (let i = this.sparks.length - 1; i >= 0; i--) {
            const s = this.sparks[i];
            s.x -= this.speed * dt;
            s.rotation += 4 * dt;

            // Magnet attraction
            if (magnetActive) {
                const dx = runner.x - s.x;
                const dy = runner.y - s.y;
                const dist = Math.sqrt(dx * dx + dy * dy);
                if (dist < magnetRange) {
                    s.x += (dx / dist) * 450 * dt;
                    s.y += (dy / dist) * 450 * dt;
                }
            }

            // Collection hit test
            const dx = runner.x - s.x;
            const dy = runner.y - s.y;
            const dist = Math.sqrt(dx * dx + dy * dy);
            if (dist < runner.radius + s.radius + 6) {
                this.sparksCollectedInRun += 1 * this.multiplier;
                this.renderer.addFloatingText(`+${this.multiplier}⚡`, s.x, s.y - 15, "#ffe600");
                if (window.neonAudio) window.neonAudio.playSpark();
                if (window.NeonFlipAdBridge) window.NeonFlipAdBridge.haptic("spark");
                this.sparks.splice(i, 1);
                continue;
            }

            if (s.x < -40) {
                this.sparks.splice(i, 1);
            }
        }

        // 2. Powerups
        for (let i = this.powerups.length - 1; i >= 0; i--) {
            const p = this.powerups[i];
            p.x -= this.speed * dt;

            const dx = runner.x - p.x;
            const dy = runner.y - p.y;
            const dist = Math.sqrt(dx * dx + dy * dy);
            if (dist < runner.radius + p.radius + 6) {
                if (p.type === "shield") {
                    const dur = window.neonProfile.getUpgradeDuration("upgrade_shield");
                    runner.activateShield(dur);
                    this.renderer.addFloatingText("SHIELD ACTIVE!", p.x, p.y - 20, "#00e5ff");
                } else if (p.type === "magnet") {
                    const dur = window.neonProfile.getUpgradeDuration("upgrade_magnet");
                    runner.activateMagnet(dur);
                    this.renderer.addFloatingText("SPARK MAGNET!", p.x, p.y - 20, "#ff9100");
                } else if (p.type === "multiplier") {
                    const dur = window.neonProfile.getUpgradeDuration("upgrade_multiplier");
                    runner.activateMultiplier(dur);
                    this.renderer.addFloatingText("2X SPARKS!", p.x, p.y - 20, "#d500f9");
                }

                this.powerups.splice(i, 1);
                continue;
            }

            if (p.x < -50) {
                this.powerups.splice(i, 1);
            }
        }
    }
}

// Global initialization
window.addEventListener("DOMContentLoaded", () => {
    window.NeonFlipGame = new NeonFlipGame();
});
