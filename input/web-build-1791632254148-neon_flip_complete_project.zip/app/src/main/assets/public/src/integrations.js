// Neon Flip - AdMob & Native Bridge Integration Client

class NeonAdMobClient {
    constructor() {
        this.isNative = false;
        this.adStatus = {
            isInitialized: false,
            isBannerLoaded: false,
            isInterstitialReady: false,
            isRewardedReady: false,
            isDebug: true
        };

        // Active reward session validation
        this.pendingRewardSession = null;
        this.eventListeners = new Map();

        this.init();
    }

    init() {
        // Detect native Android bridge
        if (typeof window.NeonFlipNativeBridge !== "undefined" || typeof window.AndroidBridge !== "undefined") {
            this.isNative = true;
            this.bridge = window.NeonFlipNativeBridge || window.AndroidBridge;
            console.log("NeonFlip: Native Android AdMob Bridge detected.");
            this.fetchStatus();
        } else {
            this.isNative = false;
            console.log("NeonFlip: Web/Browser mode active (No native bridge).");
        }

        // Listen for native custom events
        window.addEventListener("neonflip_native_ad_event", (e) => {
            if (e.detail) {
                this.onNativeAdEvent(e.detail.type, e.detail.data);
            }
        });
    }

    fetchStatus() {
        if (!this.isNative || !this.bridge) return;
        try {
            const raw = this.bridge.getAdStatus();
            if (raw) {
                const parsed = JSON.parse(raw);
                this.adStatus = Object.assign(this.adStatus, parsed);
            }
        } catch (e) {
            console.warn("Failed to parse ad status from bridge:", e);
        }
    }

    // Called directly from native Android WebView onPageFinished or event
    onNativeReady(status) {
        this.isNative = true;
        this.bridge = window.NeonFlipNativeBridge || window.AndroidBridge;
        if (status) {
            this.adStatus = Object.assign(this.adStatus, status);
        }
        console.log("NeonFlip: Native AdMob initialized and ready:", this.adStatus);
        this.trigger("ads_ready", this.adStatus);
    }

    // --- Banner Ads ---

    showBanner() {
        if (this.isNative && this.bridge && typeof this.bridge.showBanner === "function") {
            this.bridge.showBanner();
        } else {
            console.log("AdMob: [Web] showBanner requested");
        }
    }

    hideBanner() {
        if (this.isNative && this.bridge && typeof this.bridge.hideBanner === "function") {
            this.bridge.hideBanner();
        } else {
            console.log("AdMob: [Web] hideBanner requested");
        }
    }

    // --- Interstitial Ads ---

    canShowInterstitial() {
        if (this.isNative && this.bridge && typeof this.bridge.isInterstitialReady === "function") {
            return this.bridge.isInterstitialReady();
        }
        return false;
    }

    showInterstitial(runId = "run_default") {
        if (this.isNative && this.bridge && typeof this.bridge.showInterstitial === "function") {
            return this.bridge.showInterstitial(String(runId));
        } else {
            console.log("AdMob: [Web Simulation] Interstitial skipped in browser");
            return false;
        }
    }

    // --- Rewarded Ads ---

    isRewardedReady() {
        if (this.isNative && this.bridge && typeof this.bridge.isRewardedReady === "function") {
            return this.bridge.isRewardedReady();
        }
        // In browser fallback, return true for UI inspection
        return true;
    }

    /**
     * Requests a Rewarded Ad.
     * @param {string} runId Unique identifier for the run
     * @param {string} purpose "revive" | "sparks"
     * @param {object} callbacks { onReward, onClosed, onFailed, onUnavailable }
     */
    showRewarded(runId, purpose, callbacks = {}) {
        const sessionId = "run_" + (runId || Date.now()) + "_" + (purpose || "reward");

        this.pendingRewardSession = {
            sessionId: sessionId,
            runId: runId,
            purpose: purpose,
            rewardGranted: false,
            callbacks: callbacks,
            timestamp: Date.now()
        };

        if (this.isNative && this.bridge && typeof this.bridge.showRewarded === "function") {
            const started = this.bridge.showRewarded(String(runId), String(purpose));
            if (!started) {
                this.pendingRewardSession = null;
                if (callbacks.onUnavailable) callbacks.onUnavailable();
            }
        } else {
            // Browser Development Preview Flow:
            console.log(`AdMob [Browser Dev Mode]: Simulating rewarded ad for ${purpose}`);
            const confirmed = window.confirm(
                `[DEV AD SIMULATION]\n\nGoogle AdMob Rewarded Ad Preview\nPurpose: ${purpose.toUpperCase()}\n\nSimulate successful watch?`
            );
            if (confirmed) {
                setTimeout(() => {
                    this.onNativeAdEvent("ad_reward_granted", {
                        verified: true,
                        runId: runId,
                        purpose: purpose,
                        amount: 1,
                        type: purpose
                    });
                    this.onNativeAdEvent("rewarded_closed", {
                        rewardEarned: true,
                        runId: runId,
                        purpose: purpose
                    });
                }, 400);
            } else {
                setTimeout(() => {
                    this.onNativeAdEvent("rewarded_closed", {
                        rewardEarned: false,
                        runId: runId,
                        purpose: purpose
                    });
                }, 200);
            }
        }
    }

    // --- Native Callback Handler ---

    onNativeAdEvent(eventType, payload = {}) {
        console.log(`NeonFlip AdBridge event: [${eventType}]`, payload);

        switch (eventType) {
            case "ad_reward_granted":
                if (this.pendingRewardSession && payload.verified) {
                    // Match runId or purpose
                    this.pendingRewardSession.rewardGranted = true;
                    if (this.pendingRewardSession.callbacks.onReward) {
                        this.pendingRewardSession.callbacks.onReward(payload);
                    }
                }
                this.trigger("reward_granted", payload);
                break;

            case "rewarded_closed":
                if (this.pendingRewardSession) {
                    const cb = this.pendingRewardSession.callbacks.onClosed;
                    const earned = this.pendingRewardSession.rewardGranted;
                    this.pendingRewardSession = null;
                    if (cb) cb({ rewardEarned: earned });
                }
                this.trigger("rewarded_closed", payload);
                break;

            case "rewarded_failed":
            case "rewarded_unavailable":
                if (this.pendingRewardSession) {
                    const cb = (eventType === "rewarded_failed") ?
                        this.pendingRewardSession.callbacks.onFailed :
                        this.pendingRewardSession.callbacks.onUnavailable;
                    this.pendingRewardSession = null;
                    if (cb) cb(payload);
                }
                this.trigger(eventType, payload);
                break;

            case "interstitial_dismissed":
                this.trigger("interstitial_dismissed", payload);
                break;

            case "banner_loaded":
                this.adStatus.isBannerLoaded = true;
                this.trigger("banner_loaded", payload);
                break;

            case "banner_failed":
                this.adStatus.isBannerLoaded = false;
                this.trigger("banner_failed", payload);
                break;

            default:
                this.trigger(eventType, payload);
                break;
        }
    }

    // --- Haptics ---

    haptic(type = "light") {
        if (!window.neonProfile || !window.neonProfile.getSetting("haptics")) return;
        if (this.isNative && this.bridge && typeof this.bridge.triggerHaptic === "function") {
            this.bridge.triggerHaptic(type);
        } else if ("vibrate" in navigator) {
            try {
                if (type === "crash") navigator.vibrate(80);
                else if (type === "flip") navigator.vibrate(20);
                else navigator.vibrate(12);
            } catch (_) {}
        }
    }

    // --- Simple PubSub ---

    on(event, handler) {
        if (!this.eventListeners.has(event)) {
            this.eventListeners.set(event, []);
        }
        this.eventListeners.get(event).push(handler);
    }

    trigger(event, data) {
        if (this.eventListeners.has(event)) {
            this.eventListeners.get(event).forEach(fn => {
                try { fn(data); } catch(e) { console.error(e); }
            });
        }
    }
}

window.NeonFlipAdBridge = new NeonAdMobClient();
