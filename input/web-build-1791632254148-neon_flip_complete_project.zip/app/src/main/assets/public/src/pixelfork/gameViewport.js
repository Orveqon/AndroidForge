// Neon Flip - Responsive Viewport & Canvas Scaler

class GameViewport {
    constructor(canvas, virtualWidth = 480, virtualHeight = 800) {
        this.canvas = canvas;
        this.virtualWidth = virtualWidth;
        this.virtualHeight = virtualHeight;
        this.scale = 1;
        this.offsetX = 0;
        this.offsetY = 0;
        this.cssWidth = 0;
        this.cssHeight = 0;
        this.dpr = Math.min(window.devicePixelRatio || 1, 2.5);

        this.resize();
        window.addEventListener("resize", () => this.resize());
        window.addEventListener("orientationchange", () => setTimeout(() => this.resize(), 100));
    }

    resize() {
        const winW = window.innerWidth;
        const winH = window.innerHeight;

        this.dpr = Math.min(window.devicePixelRatio || 1, 2.5);

        // Aspect fit virtual canvas inside window
        const scaleX = winW / this.virtualWidth;
        const scaleY = winH / this.virtualHeight;
        this.scale = Math.min(scaleX, scaleY);

        this.cssWidth = Math.round(this.virtualWidth * this.scale);
        this.cssHeight = Math.round(this.virtualHeight * this.scale);
        this.offsetX = Math.round((winW - this.cssWidth) / 2);
        this.offsetY = Math.round((winH - this.cssHeight) / 2);

        this.canvas.width = Math.round(this.cssWidth * this.dpr);
        this.canvas.height = Math.round(this.cssHeight * this.dpr);

        this.canvas.style.width = `${this.cssWidth}px`;
        this.canvas.style.height = `${this.cssHeight}px`;
        this.canvas.style.left = `${this.offsetX}px`;
        this.canvas.style.top = `${this.offsetY}px`;
    }

    screenToVirtual(screenX, screenY) {
        const localX = screenX - this.offsetX;
        const localY = screenY - this.offsetY;
        return {
            x: localX / this.scale,
            y: localY / this.scale
        };
    }
}

if (typeof module !== "undefined" && module.exports) {
    module.exports = GameViewport;
}
