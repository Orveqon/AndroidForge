// Neon Flip - UI & Menu Interface System

class NeonUIManager {
    constructor(game) {
        this.game = game;

        // Overlay Elements
        this.menuScreen = document.getElementById("screen-menu");
        this.gameplayHud = document.getElementById("screen-hud");
        this.gameOverScreen = document.getElementById("screen-game-over");
        this.pauseScreen = document.getElementById("screen-pause");
        this.shopScreen = document.getElementById("screen-shop");
        this.settingsModal = document.getElementById("modal-settings");
        this.toastEl = document.getElementById("ui-toast");

        // HUD labels
        this.hudScore = document.getElementById("hud-score");
        this.hudSparks = document.getElementById("hud-sparks");
        this.hudMultiplier = document.getElementById("hud-multiplier");

        // Game over labels
        this.goScore = document.getElementById("go-score");
        this.goBest = document.getElementById("go-best");
        this.goSparks = document.getElementById("go-sparks");
        this.goNewBest = document.getElementById("go-new-best");
        this.goReviveBtn = document.getElementById("btn-revive-ad");

        // Shop labels
        this.shopSparksBalance = document.getElementById("shop-sparks-balance");
        this.shopSkinsContainer = document.getElementById("shop-skins-list");
        this.shopUpgradesContainer = document.getElementById("shop-upgrades-list");

        this.reviveCountdownTimer = null;
        this.bindEvents();
    }

    bindEvents() {
        // Menu Buttons
        document.getElementById("btn-play")?.addEventListener("click", () => {
            if (window.neonAudio) window.neonAudio.playClick();
            this.game.startRun();
        });

        document.getElementById("btn-shop")?.addEventListener("click", () => {
            if (window.neonAudio) window.neonAudio.playClick();
            this.showShop();
        });

        document.getElementById("btn-settings")?.addEventListener("click", () => {
            if (window.neonAudio) window.neonAudio.playClick();
            this.showSettings();
        });

        // Pause Buttons
        document.getElementById("btn-pause-toggle")?.addEventListener("click", (e) => {
            e.stopPropagation();
            if (window.neonAudio) window.neonAudio.playClick();
            this.game.togglePause();
        });

        document.getElementById("btn-resume")?.addEventListener("click", () => {
            if (window.neonAudio) window.neonAudio.playClick();
            this.game.togglePause();
        });

        document.getElementById("btn-pause-restart")?.addEventListener("click", () => {
            if (window.neonAudio) window.neonAudio.playClick();
            this.game.startRun();
        });

        document.getElementById("btn-pause-menu")?.addEventListener("click", () => {
            if (window.neonAudio) window.neonAudio.playClick();
            this.showMenu();
        });

        // Game Over Buttons
        document.getElementById("btn-restart")?.addEventListener("click", () => {
            if (window.neonAudio) window.neonAudio.playClick();
            this.game.onGameOverAction("restart");
        });

        document.getElementById("btn-menu")?.addEventListener("click", () => {
            if (window.neonAudio) window.neonAudio.playClick();
            this.game.onGameOverAction("menu");
        });

        // Rewarded Revive Action
        this.goReviveBtn?.addEventListener("click", () => {
            if (window.neonAudio) window.neonAudio.playClick();
            this.handleReviveClick();
        });

        // Free Sparks Ad Action in Shop
        document.getElementById("btn-free-sparks-ad")?.addEventListener("click", () => {
            if (window.neonAudio) window.neonAudio.playClick();
            this.handleFreeSparksClick();
        });

        // Shop Navigation
        document.getElementById("btn-shop-back")?.addEventListener("click", () => {
            if (window.neonAudio) window.neonAudio.playClick();
            this.showMenu();
        });

        // Settings Modal
        document.getElementById("btn-close-settings")?.addEventListener("click", () => {
            if (window.neonAudio) window.neonAudio.playClick();
            this.hideSettings();
        });

        // Settings toggles
        document.getElementById("toggle-sound")?.addEventListener("change", (e) => {
            window.neonProfile.setSetting("sound", e.target.checked);
        });

        document.getElementById("toggle-music")?.addEventListener("change", (e) => {
            window.neonProfile.setSetting("music", e.target.checked);
        });

        document.getElementById("toggle-haptics")?.addEventListener("change", (e) => {
            window.neonProfile.setSetting("haptics", e.target.checked);
        });

        document.getElementById("toggle-shake")?.addEventListener("change", (e) => {
            window.neonProfile.setSetting("screenShake", e.target.checked);
        });

        document.getElementById("btn-privacy-consent")?.addEventListener("click", () => {
            if (window.NeonFlipAdBridge) {
                window.NeonFlipAdBridge.showBanner();
                if (window.NeonFlipAdBridge.isNative && window.NeonFlipAdBridge.bridge) {
                    window.NeonFlipAdBridge.bridge.requestConsent();
                }
            }
            this.showToast("Opening Consent & Privacy Dialog...");
        });
    }

    showMenu() {
        this.hideAllScreens();
        this.menuScreen.classList.remove("hidden");
        document.getElementById("menu-high-score").textContent = window.neonProfile.getHighScore();
        document.getElementById("menu-sparks").textContent = window.neonProfile.getSparks();

        // Show banner outside active gameplay
        if (window.NeonFlipAdBridge) {
            window.NeonFlipAdBridge.showBanner();
        }
    }

    showGameplay() {
        this.hideAllScreens();
        this.gameplayHud.classList.remove("hidden");

        // Hide banner during active gameplay
        if (window.NeonFlipAdBridge) {
            window.NeonFlipAdBridge.hideBanner();
        }
    }

    showPause() {
        this.pauseScreen.classList.remove("hidden");
        // Show banner while paused
        if (window.NeonFlipAdBridge) {
            window.NeonFlipAdBridge.showBanner();
        }
    }

    hidePause() {
        this.pauseScreen.classList.add("hidden");
        if (window.NeonFlipAdBridge) {
            window.NeonFlipAdBridge.hideBanner();
        }
    }

    showGameOver(stats, canRevive) {
        this.hideAllScreens();
        this.gameOverScreen.classList.remove("hidden");

        this.goScore.textContent = stats.score;
        this.goBest.textContent = window.neonProfile.getHighScore();
        this.goSparks.textContent = `+${stats.sparksEarned}`;

        if (stats.isNewHighScore) {
            this.goNewBest.classList.remove("hidden");
        } else {
            this.goNewBest.classList.add("hidden");
        }

        // Revive button handling
        if (canRevive) {
            this.goReviveBtn.classList.remove("hidden");
            this.startReviveCountdown();
        } else {
            this.goReviveBtn.classList.add("hidden");
            this.stopReviveCountdown();
        }

        // Show banner on Game Over screen
        if (window.NeonFlipAdBridge) {
            window.NeonFlipAdBridge.showBanner();
        }
    }

    startReviveCountdown() {
        let secondsLeft = 5;
        this.goReviveBtn.textContent = `⚡ REVIVE (1/1) - AD (${secondsLeft}s)`;

        if (this.reviveCountdownTimer) clearInterval(this.reviveCountdownTimer);
        this.reviveCountdownTimer = setInterval(() => {
            secondsLeft--;
            if (secondsLeft <= 0) {
                this.stopReviveCountdown();
                this.goReviveBtn.textContent = "⚡ REVIVE (1/1) - WATCH AD";
            } else {
                this.goReviveBtn.textContent = `⚡ REVIVE (1/1) - AD (${secondsLeft}s)`;
            }
        }, 1000);
    }

    stopReviveCountdown() {
        if (this.reviveCountdownTimer) {
            clearInterval(this.reviveCountdownTimer);
            this.reviveCountdownTimer = null;
        }
    }

    handleReviveClick() {
        this.stopReviveCountdown();
        this.goReviveBtn.disabled = true;
        this.goReviveBtn.textContent = "Loading Ad...";

        const runId = this.game.currentRunId;

        window.NeonFlipAdBridge.showRewarded(runId, "revive", {
            onReward: (rewardData) => {
                console.log("Verified AdMob Revive Reward earned!", rewardData);
                this.showToast("REVIVED! ⚡ Invulnerability Shield Active!");
                this.game.executeRevive();
            },
            onClosed: (res) => {
                this.goReviveBtn.disabled = false;
                this.goReviveBtn.textContent = "⚡ REVIVE (1/1) - WATCH AD";
                if (!res.rewardEarned) {
                    this.showToast("Ad closed without completing. No revive.");
                }
            },
            onFailed: (err) => {
                this.goReviveBtn.disabled = false;
                this.goReviveBtn.textContent = "⚡ REVIVE (1/1) - WATCH AD";
                this.showToast("Ad failed to load. Please try again.");
            },
            onUnavailable: () => {
                this.goReviveBtn.disabled = false;
                this.goReviveBtn.textContent = "⚡ REVIVE (1/1) - WATCH AD";
                this.showToast("Rewarded ad currently unavailable.");
            }
        });
    }

    handleFreeSparksClick() {
        const btn = document.getElementById("btn-free-sparks-ad");
        if (btn) btn.disabled = true;

        window.NeonFlipAdBridge.showRewarded("shop_reward", "sparks", {
            onReward: (rewardData) => {
                window.neonProfile.addSparks(NEON_CONFIG.ads.rewardedSparksBonus);
                this.updateShopSparks();
                this.showToast(`+${NEON_CONFIG.ads.rewardedSparksBonus} Free Neon Sparks Granted!`);
                if (window.neonAudio) window.neonAudio.playRevive();
            },
            onClosed: (res) => {
                if (btn) btn.disabled = false;
            },
            onFailed: (err) => {
                if (btn) btn.disabled = false;
                this.showToast("Ad failed to load.");
            },
            onUnavailable: () => {
                if (btn) btn.disabled = false;
                this.showToast("Ad not ready yet. Please check connection.");
            }
        });
    }

    showShop() {
        this.hideAllScreens();
        this.shopScreen.classList.remove("hidden");
        this.updateShopSparks();
        this.renderShopItems();

        if (window.NeonFlipAdBridge) {
            window.NeonFlipAdBridge.showBanner();
        }
    }

    updateShopSparks() {
        if (this.shopSparksBalance) {
            this.shopSparksBalance.textContent = window.neonProfile.getSparks();
        }
    }

    renderShopItems() {
        // 1. Render Skins
        if (this.shopSkinsContainer) {
            this.shopSkinsContainer.innerHTML = "";
            NEON_CONFIG.skins.forEach(skin => {
                const isUnlocked = window.neonProfile.isSkinUnlocked(skin.id);
                const isEquipped = window.neonProfile.getSelectedSkin().id === skin.id;

                const itemEl = document.createElement("div");
                itemEl.className = `shop-item-card ${isEquipped ? "equipped" : ""}`;
                itemEl.innerHTML = `
                    <div class="skin-preview-icon" style="background:${skin.primaryColor}; box-shadow: 0 0 16px ${skin.glowColor}; border: 2px solid ${skin.secondaryColor};"></div>
                    <div class="shop-item-info">
                        <div class="shop-item-title">${skin.name}</div>
                        <div class="shop-item-desc">${skin.desc}</div>
                    </div>
                    <div class="shop-item-action">
                        ${isEquipped ? '<span class="badge-equipped">EQUIPPED</span>' :
                          isUnlocked ? `<button class="btn-neon-action btn-equip" data-id="${skin.id}">EQUIP</button>` :
                          `<button class="btn-neon-action btn-buy" data-id="${skin.id}">⚡ ${skin.cost}</button>`}
                    </div>
                `;
                this.shopSkinsContainer.appendChild(itemEl);
            });

            // Bind equip/buy skin clicks
            this.shopSkinsContainer.querySelectorAll(".btn-equip").forEach(btn => {
                btn.addEventListener("click", () => {
                    const id = btn.getAttribute("data-id");
                    window.neonProfile.equipSkin(id);
                    this.game.runner.applySkin(window.neonProfile.getSelectedSkin());
                    this.renderShopItems();
                    if (window.neonAudio) window.neonAudio.playClick();
                });
            });

            this.shopSkinsContainer.querySelectorAll(".btn-buy").forEach(btn => {
                btn.addEventListener("click", () => {
                    const id = btn.getAttribute("data-id");
                    if (window.neonProfile.unlockSkin(id)) {
                        this.game.runner.applySkin(window.neonProfile.getSelectedSkin());
                        this.updateShopSparks();
                        this.renderShopItems();
                        this.showToast("Skin Unlocked & Equipped!");
                        if (window.neonAudio) window.neonAudio.playShield();
                    } else {
                        this.showToast("Not enough Neon Sparks!");
                    }
                });
            });
        }

        // 2. Render Upgrades
        if (this.shopUpgradesContainer) {
            this.shopUpgradesContainer.innerHTML = "";
            NEON_CONFIG.upgrades.forEach(upg => {
                const currentLvl = window.neonProfile.getUpgradeLevel(upg.id);
                const cost = window.neonProfile.getUpgradeCost(upg.id);
                const isMax = currentLvl >= upg.maxLevel;

                const itemEl = document.createElement("div");
                itemEl.className = "shop-item-card";
                itemEl.innerHTML = `
                    <div class="upgrade-icon">⚡</div>
                    <div class="shop-item-info">
                        <div class="shop-item-title">${upg.name} <span class="badge-level">Lvl ${currentLvl}/${upg.maxLevel}</span></div>
                        <div class="shop-item-desc">${upg.desc} (${window.neonProfile.getUpgradeDuration(upg.id).toFixed(1)}s)</div>
                    </div>
                    <div class="shop-item-action">
                        ${isMax ? '<span class="badge-equipped">MAXED</span>' :
                          `<button class="btn-neon-action btn-upgrade" data-id="${upg.id}">⚡ ${cost}</button>`}
                    </div>
                `;
                this.shopUpgradesContainer.appendChild(itemEl);
            });

            this.shopUpgradesContainer.querySelectorAll(".btn-upgrade").forEach(btn => {
                btn.addEventListener("click", () => {
                    const id = btn.getAttribute("data-id");
                    if (window.neonProfile.buyUpgrade(id)) {
                        this.updateShopSparks();
                        this.renderShopItems();
                        this.showToast("Power-up Upgraded!");
                        if (window.neonAudio) window.neonAudio.playShield();
                    } else {
                        this.showToast("Not enough Neon Sparks!");
                    }
                });
            });
        }
    }

    showSettings() {
        this.settingsModal.classList.remove("hidden");

        const soundToggle = document.getElementById("toggle-sound");
        const musicToggle = document.getElementById("toggle-music");
        const hapticsToggle = document.getElementById("toggle-haptics");
        const shakeToggle = document.getElementById("toggle-shake");

        if (soundToggle) soundToggle.checked = window.neonProfile.getSetting("sound");
        if (musicToggle) musicToggle.checked = window.neonProfile.getSetting("music");
        if (hapticsToggle) hapticsToggle.checked = window.neonProfile.getSetting("haptics");
        if (shakeToggle) shakeToggle.checked = window.neonProfile.getSetting("screenShake");

        // Display ad status
        const adStatusEl = document.getElementById("settings-ad-status");
        if (adStatusEl && window.NeonFlipAdBridge) {
            const status = window.NeonFlipAdBridge.adStatus;
            adStatusEl.textContent = `Mode: ${status.isDebug ? "Google Test Ads" : "Production AdMob"} | Native: ${window.NeonFlipAdBridge.isNative ? "Connected" : "Web Preview"}`;
        }
    }

    hideSettings() {
        this.settingsModal.classList.add("hidden");
    }

    updateHud(score, sparks, multiplier) {
        if (this.hudScore) this.hudScore.textContent = score;
        if (this.hudSparks) this.hudSparks.textContent = sparks;
        if (this.hudMultiplier) {
            if (multiplier > 1) {
                this.hudMultiplier.textContent = `x${multiplier}`;
                this.hudMultiplier.classList.remove("hidden");
            } else {
                this.hudMultiplier.classList.add("hidden");
            }
        }
    }

    showToast(message) {
        if (!this.toastEl) return;
        this.toastEl.textContent = message;
        this.toastEl.classList.remove("hidden");
        this.toastEl.classList.add("visible");

        clearTimeout(this.toastTimeout);
        this.toastTimeout = setTimeout(() => {
            this.toastEl.classList.remove("visible");
            setTimeout(() => this.toastEl.classList.add("hidden"), 300);
        }, 2500);
    }

    hideAllScreens() {
        this.menuScreen.classList.add("hidden");
        this.gameplayHud.classList.add("hidden");
        this.gameOverScreen.classList.add("hidden");
        this.pauseScreen.classList.add("hidden");
        this.shopScreen.classList.add("hidden");
    }
}

if (typeof module !== "undefined" && module.exports) {
    module.exports = NeonUIManager;
}
