# Privacy Policy for Neon Flip

**Last updated:** October 10, 2026

Neon Flip ("we", "our", or "us") provides this Privacy Policy to explain how information is collected, used, and disclosed when you use our mobile application.

## 1. Information Collected
Neon Flip does not collect any personal identifying information (such as your name, email address, or phone number) directly on our servers.
Game save progress (high score, currency, unlocked skins) is stored locally on your device.

## 2. Advertising and Analytics
We use Google AdMob to display advertisements in the application. Google AdMob and its advertising partners may collect and process device-specific information, advertising identifiers, and general location data to serve personalized or non-personalized ads in compliance with applicable laws and consent choices:
- Google AdMob: [https://policies.google.com/technologies/ads](https://policies.google.com/technologies/ads)

## 3. User Messaging Platform (UMP) & GDPR / CCPA Consent
In regions where consent is legally required (including the European Economic Area, the UK, and California), Neon Flip integrates Google's User Messaging Platform (UMP) to gather and respect your consent preferences regarding personalized advertising and tracking cookies/identifiers. You can update your consent preferences at any time in the in-game Settings menu.

## 4. Children's Privacy
Neon Flip does not knowingly collect personally identifiable information from children under the age of 13.

## 5. Contact
For questions regarding this Privacy Policy, please contact the developer via the support email listed in Google Play Store.
