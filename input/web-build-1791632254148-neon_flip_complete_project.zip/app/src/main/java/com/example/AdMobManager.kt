package com.example

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Manages Google AdMob initialization, UMP consent, Banner, Interstitial,
 * and Rewarded ads with robust lifecycle and error handling.
 */
class AdMobManager(
    private val activity: Activity,
    private val bannerContainer: FrameLayout,
    private val listener: AdEventListener
) {
    companion object {
        private const val TAG = "NeonFlip_AdMob"
        private const val INTERSTITIAL_COOLDOWN_MS = 60_000L // 60 seconds minimum between interstitials
    }

    interface AdEventListener {
        fun onAdEvent(eventType: String, payloadJson: String)
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val isMobileAdsInitialized = AtomicBoolean(false)

    // Ad instances
    private var adView: AdView? = null
    private var interstitialAd: InterstitialAd? = null
    private var rewardedAd: RewardedAd? = null

    // State tracking
    private var isBannerLoaded = false
    private var isBannerRequestedVisible = false
    private var isInterstitialLoading = false
    private var isRewardedLoading = false
    private var lastInterstitialShowTime = 0L

    // Active ad session tracking
    private var currentRewardedRunId: String = ""
    private var currentRewardedPurpose: String = ""
    private var rewardEarnedInSession = false

    init {
        initConsentAndAds()
    }

    /**
     * Initializes Google User Messaging Platform (UMP) consent flow,
     * then initializes the Mobile Ads SDK.
     */
    fun initConsentAndAds() {
        val params = ConsentRequestParameters.Builder()
            .setTagForUnderAgeOfConsent(false)
            .build()

        val consentInformation = UserMessagingPlatform.getConsentInformation(activity)

        consentInformation.requestConsentInfoUpdate(
            activity,
            params,
            {
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { formError ->
                    if (formError != null) {
                        Log.w(TAG, "UMP consent form error: ${formError.message}")
                    }
                    if (consentInformation.canRequestAds()) {
                        initializeMobileAds()
                    }
                    dispatchConsentStatus(consentInformation.canRequestAds())
                }
            },
            { requestError ->
                Log.w(TAG, "UMP consent request failed: ${requestError.message}")
                if (consentInformation.canRequestAds()) {
                    initializeMobileAds()
                }
                dispatchConsentStatus(consentInformation.canRequestAds())
            }
        )
    }

    private fun dispatchConsentStatus(canRequest: Boolean) {
        val payload = """{"canRequestAds":$canRequest,"isDebug":${BuildConfig.IS_DEBUG_ADS}}"""
        listener.onAdEvent("consent_status", payload)
    }

    private fun initializeMobileAds() {
        if (isMobileAdsInitialized.getAndSet(true)) return

        Log.i(TAG, "Initializing Mobile Ads SDK (Debug mode: ${BuildConfig.IS_DEBUG_ADS})")

        val reqConfig = MobileAds.getRequestConfiguration().toBuilder()
            .setTagForChildDirectedTreatment(com.google.android.gms.ads.RequestConfiguration.TAG_FOR_CHILD_DIRECTED_TREATMENT_FALSE)
            .build()
        MobileAds.setRequestConfiguration(reqConfig)

        MobileAds.initialize(activity) { initStatus ->
            Log.i(TAG, "Mobile Ads SDK initialized successfully: ${initStatus.adapterStatusMap}")
            mainHandler.post {
                listener.onAdEvent("ads_initialized", """{"status":"ready","isDebug":${BuildConfig.IS_DEBUG_ADS}}""")
                loadBannerAd()
                // Stagger loading to prevent network contention on startup
                mainHandler.postDelayed({ loadInterstitialAd() }, 1500L)
                mainHandler.postDelayed({ loadRewardedAd() }, 3000L)
            }
        }
    }

    // ------------------------------------------------------------------------
    // Banner Ads
    // ------------------------------------------------------------------------

    private fun getAdaptiveAdSize(): AdSize {
        val display = activity.windowManager.defaultDisplay
        val outMetrics = DisplayMetrics()
        display.getMetrics(outMetrics)
        val density = outMetrics.density
        var adWidthPixels = bannerContainer.width.toFloat()
        if (adWidthPixels <= 0f) {
            adWidthPixels = outMetrics.widthPixels.toFloat()
        }
        val adWidth = (adWidthPixels / density).toInt()
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(activity, adWidth)
    }

    private fun loadBannerAd() {
        if (!isMobileAdsInitialized.get()) return

        mainHandler.post {
            try {
                if (adView == null) {
                    val newAdView = AdView(activity).apply {
                        adUnitId = BuildConfig.ADMOB_BANNER_ID
                        setAdSize(getAdaptiveAdSize())
                        adListener = object : AdListener() {
                            override fun onAdLoaded() {
                                isBannerLoaded = true
                                Log.i(TAG, "Banner ad loaded successfully")
                                listener.onAdEvent("banner_loaded", """{"status":"loaded"}""")
                                updateBannerVisibility()
                            }

                            override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                                isBannerLoaded = false
                                Log.w(TAG, "Banner ad failed to load: ${loadAdError.message} (code: ${loadAdError.code})")
                                listener.onAdEvent("banner_failed", """{"code":${loadAdError.code},"message":"${loadAdError.message}"}""")
                                bannerContainer.visibility = View.GONE
                                // Retry banner after 30 seconds
                                mainHandler.postDelayed({ loadBannerAd() }, 30_000L)
                            }

                            override fun onAdOpened() {
                                listener.onAdEvent("banner_opened", """{}""")
                            }

                            override fun onAdClosed() {
                                listener.onAdEvent("banner_closed", """{}""")
                            }
                        }
                    }
                    bannerContainer.removeAllViews()
                    bannerContainer.addView(newAdView)
                    adView = newAdView
                }

                val adRequest = AdRequest.Builder().build()
                adView?.loadAd(adRequest)
            } catch (e: Exception) {
                Log.e(TAG, "Error loading banner ad", e)
            }
        }
    }

    fun showBanner() {
        isBannerRequestedVisible = true
        mainHandler.post {
            updateBannerVisibility()
            if (!isBannerLoaded) {
                loadBannerAd()
            }
        }
    }

    fun hideBanner() {
        isBannerRequestedVisible = false
        mainHandler.post {
            bannerContainer.visibility = View.GONE
        }
    }

    private fun updateBannerVisibility() {
        if (isBannerRequestedVisible && isBannerLoaded) {
            bannerContainer.visibility = View.VISIBLE
        } else {
            bannerContainer.visibility = View.GONE
        }
    }

    // ------------------------------------------------------------------------
    // Interstitial Ads
    // ------------------------------------------------------------------------

    fun loadInterstitialAd() {
        if (!isMobileAdsInitialized.get() || isInterstitialLoading || interstitialAd != null) return

        isInterstitialLoading = true
        val adRequest = AdRequest.Builder().build()

        InterstitialAd.load(
            activity,
            BuildConfig.ADMOB_INTERSTITIAL_ID,
            adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                    isInterstitialLoading = false
                    Log.i(TAG, "Interstitial ad loaded successfully")
                    listener.onAdEvent("interstitial_loaded", """{"status":"ready"}""")

                    ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                        override fun onAdDismissedFullScreenContent() {
                            Log.i(TAG, "Interstitial ad dismissed")
                            interstitialAd = null
                            lastInterstitialShowTime = System.currentTimeMillis()
                            listener.onAdEvent("interstitial_dismissed", """{"status":"dismissed"}""")
                            // Preload next interstitial
                            loadInterstitialAd()
                        }

                        override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                            Log.w(TAG, "Interstitial failed to show: ${adError.message}")
                            interstitialAd = null
                            listener.onAdEvent("interstitial_failed", """{"code":${adError.code},"message":"${adError.message}"}""")
                            loadInterstitialAd()
                        }

                        override fun onAdShowedFullScreenContent() {
                            Log.i(TAG, "Interstitial ad displayed")
                            listener.onAdEvent("interstitial_showed", """{"status":"showed"}""")
                        }
                    }
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    interstitialAd = null
                    isInterstitialLoading = false
                    Log.w(TAG, "Interstitial ad failed to load: ${loadAdError.message}")
                    listener.onAdEvent("interstitial_load_failed", """{"code":${loadAdError.code},"message":"${loadAdError.message}"}""")
                    // Retry loading after 20 seconds
                    mainHandler.postDelayed({ loadInterstitialAd() }, 20_000L)
                }
            }
        )
    }

    fun isInterstitialReady(): Boolean {
        val now = System.currentTimeMillis()
        val cooldownPassed = (now - lastInterstitialShowTime) >= INTERSTITIAL_COOLDOWN_MS
        return interstitialAd != null && cooldownPassed
    }

    fun showInterstitial(runId: String): Boolean {
        return if (isInterstitialReady()) {
            mainHandler.post {
                interstitialAd?.show(activity)
            }
            true
        } else {
            Log.d(TAG, "Interstitial ad not ready or cooldown in effect")
            listener.onAdEvent("interstitial_unavailable", """{"runId":"$runId"}""")
            loadInterstitialAd()
            false
        }
    }

    // ------------------------------------------------------------------------
    // Rewarded Ads
    // ------------------------------------------------------------------------

    fun loadRewardedAd() {
        if (!isMobileAdsInitialized.get() || isRewardedLoading || rewardedAd != null) return

        isRewardedLoading = true
        val adRequest = AdRequest.Builder().build()

        RewardedAd.load(
            activity,
            BuildConfig.ADMOB_REWARDED_ID,
            adRequest,
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                    isRewardedLoading = false
                    Log.i(TAG, "Rewarded ad loaded successfully")
                    listener.onAdEvent("rewarded_loaded", """{"status":"ready"}""")

                    ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                        override fun onAdDismissedFullScreenContent() {
                            Log.i(TAG, "Rewarded ad closed by user. Reward earned: $rewardEarnedInSession")
                            val earned = rewardEarnedInSession
                            val runId = currentRewardedRunId
                            val purpose = currentRewardedPurpose

                            rewardedAd = null
                            currentRewardedRunId = ""
                            currentRewardedPurpose = ""
                            rewardEarnedInSession = false

                            listener.onAdEvent(
                                "rewarded_closed",
                                """{"rewardEarned":$earned,"runId":"$runId","purpose":"$purpose"}"""
                            )

                            // Preload next rewarded ad
                            loadRewardedAd()
                        }

                        override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                            Log.w(TAG, "Rewarded ad failed to show: ${adError.message}")
                            val runId = currentRewardedRunId
                            val purpose = currentRewardedPurpose

                            rewardedAd = null
                            rewardEarnedInSession = false

                            listener.onAdEvent(
                                "rewarded_failed",
                                """{"code":${adError.code},"message":"${adError.message}","runId":"$runId","purpose":"$purpose"}"""
                            )
                            loadRewardedAd()
                        }

                        override fun onAdShowedFullScreenContent() {
                            Log.i(TAG, "Rewarded ad showed full screen")
                            listener.onAdEvent("rewarded_showed", """{}""")
                        }
                    }
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    rewardedAd = null
                    isRewardedLoading = false
                    Log.w(TAG, "Rewarded ad failed to load: ${loadAdError.message}")
                    listener.onAdEvent("rewarded_load_failed", """{"code":${loadAdError.code},"message":"${loadAdError.message}"}""")
                    mainHandler.postDelayed({ loadRewardedAd() }, 15_000L)
                }
            }
        )
    }

    fun isRewardedReady(): Boolean {
        return rewardedAd != null
    }

    /**
     * Shows the rewarded ad.
     * The reward is granted ONLY when the verified native callback is invoked!
     */
    fun showRewarded(runId: String, purpose: String): Boolean {
        val ad = rewardedAd
        if (ad == null) {
            Log.w(TAG, "Rewarded ad requested but not ready")
            listener.onAdEvent("rewarded_unavailable", """{"runId":"$runId","purpose":"$purpose"}""")
            loadRewardedAd()
            return false
        }

        currentRewardedRunId = runId
        currentRewardedPurpose = purpose
        rewardEarnedInSession = false

        mainHandler.post {
            ad.show(activity) { rewardItem ->
                // CRITICAL: Grant reward ONLY here from verified native SDK callback!
                rewardEarnedInSession = true
                val amount = rewardItem.amount
                val type = rewardItem.type
                Log.i(TAG, "Rewarded callback verified: $amount $type for run: $runId, purpose: $purpose")

                val payload = """{
                    "verified": true,
                    "amount": $amount,
                    "type": "$type",
                    "runId": "$runId",
                    "purpose": "$purpose"
                }""".trimIndent()

                listener.onAdEvent("ad_reward_granted", payload)
            }
        }
        return true
    }

    // ------------------------------------------------------------------------
    // Lifecycle & Status
    // ------------------------------------------------------------------------

    fun getAdStatusJson(): String {
        return """{
            "isInitialized": ${isMobileAdsInitialized.get()},
            "isBannerLoaded": $isBannerLoaded,
            "isInterstitialReady": ${isInterstitialReady()},
            "isRewardedReady": ${isRewardedReady()},
            "isDebug": ${BuildConfig.IS_DEBUG_ADS}
        }""".trimIndent()
    }

    fun onResume() {
        adView?.resume()
        // Refresh ad readiness if empty
        if (interstitialAd == null) loadInterstitialAd()
        if (rewardedAd == null) loadRewardedAd()
    }

    fun onPause() {
        adView?.pause()
    }

    fun onDestroy() {
        adView?.destroy()
        adView = null
        interstitialAd = null
        rewardedAd = null
    }
}
