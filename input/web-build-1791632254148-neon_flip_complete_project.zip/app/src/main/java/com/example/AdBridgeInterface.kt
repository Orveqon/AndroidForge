package com.example

import android.app.Activity
import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebView

/**
 * JavaScript interface that bridges Neon Flip web runtime with native Android AdMob and device features.
 */
class AdBridgeInterface(
    private val activity: Activity,
    private val webView: WebView,
    private val adMobManager: AdMobManager
) {
    companion object {
        private const val TAG = "NeonFlip_Bridge"
    }

    private val vibrator: Vibrator? by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = activity.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vibratorManager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            activity.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }

    @JavascriptInterface
    fun showBanner() {
        Log.d(TAG, "JS called showBanner")
        adMobManager.showBanner()
    }

    @JavascriptInterface
    fun hideBanner() {
        Log.d(TAG, "JS called hideBanner")
        adMobManager.hideBanner()
    }

    @JavascriptInterface
    fun showInterstitial(runId: String?): Boolean {
        Log.d(TAG, "JS called showInterstitial, runId: $runId")
        return adMobManager.showInterstitial(runId ?: "unknown")
    }

    @JavascriptInterface
    fun showRewarded(runId: String?, purpose: String?): Boolean {
        Log.d(TAG, "JS called showRewarded, runId: $runId, purpose: $purpose")
        return adMobManager.showRewarded(runId ?: "unknown", purpose ?: "revive")
    }

    @JavascriptInterface
    fun isRewardedReady(): Boolean {
        return adMobManager.isRewardedReady()
    }

    @JavascriptInterface
    fun isInterstitialReady(): Boolean {
        return adMobManager.isInterstitialReady()
    }

    @JavascriptInterface
    fun requestConsent() {
        Log.d(TAG, "JS called requestConsent")
        activity.runOnUiThread {
            adMobManager.initConsentAndAds()
        }
    }

    @JavascriptInterface
    fun getAdStatus(): String {
        return adMobManager.getAdStatusJson()
    }

    @JavascriptInterface
    fun getPlatformInfo(): String {
        return """{
            "platform": "android",
            "versionName": "${BuildConfig.VERSION_NAME}",
            "versionCode": ${BuildConfig.VERSION_CODE},
            "isDebug": ${BuildConfig.IS_DEBUG_ADS},
            "sdkInt": ${Build.VERSION.SDK_INT}
        }""".trimIndent()
    }

    @JavascriptInterface
    fun triggerHaptic(type: String?) {
        try {
            val vib = vibrator ?: return
            if (!vib.hasVibrator()) return

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                when (type) {
                    "light", "spark" -> {
                        vib.vibrate(VibrationEffect.createOneShot(15, VibrationEffect.DEFAULT_AMPLITUDE))
                    }
                    "flip" -> {
                        vib.vibrate(VibrationEffect.createOneShot(25, 180))
                    }
                    "shield", "powerup" -> {
                        vib.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 30, 40, 30), intArrayOf(0, 150, 0, 255), -1))
                    }
                    "crash", "gameover" -> {
                        vib.vibrate(VibrationEffect.createOneShot(100, 255))
                    }
                    else -> {
                        vib.vibrate(VibrationEffect.createOneShot(20, VibrationEffect.DEFAULT_AMPLITUDE))
                    }
                }
            } else {
                @Suppress("DEPRECATION")
                when (type) {
                    "light", "spark" -> vib.vibrate(15)
                    "flip" -> vib.vibrate(25)
                    "crash", "gameover" -> vib.vibrate(100)
                    else -> vib.vibrate(20)
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Haptic feedback error: ${e.message}")
        }
    }

    /**
     * Dispatches an asynchronous native ad event into the WebView JavaScript runtime.
     */
    fun dispatchEventToWeb(eventType: String, payloadJson: String) {
        activity.runOnUiThread {
            // Escape any unescaped backslashes and quotes for safe JS injection
            val safePayload = if (payloadJson.isBlank()) "{}" else payloadJson
            val js = """
                (function() {
                    try {
                        var payload = $safePayload;
                        if (window.NeonFlipAdBridge && typeof window.NeonFlipAdBridge.onNativeAdEvent === 'function') {
                            window.NeonFlipAdBridge.onNativeAdEvent('$eventType', payload);
                        }
                        var evt = new CustomEvent('neonflip_native_ad_event', { detail: { type: '$eventType', data: payload } });
                        window.dispatchEvent(evt);
                    } catch(e) {
                        console.error('Bridge event dispatch error:', e);
                    }
                })();
            """.trimIndent()

            webView.evaluateJavascript(js, null)
        }
    }
}
