package com.example

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.webkit.WebViewAssetLoader

class MainActivity : ComponentActivity() {

    companion object {
        private const val TAG = "NeonFlip_Activity"
    }

    private lateinit var rootLayout: FrameLayout
    private lateinit var webView: WebView
    private lateinit var bannerContainer: FrameLayout
    private lateinit var adMobManager: AdMobManager
    private lateinit var bridge: AdBridgeInterface
    private var assetLoader: WebViewAssetLoader? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Make window background deep neon night
        window.decorView.setBackgroundColor(Color.parseColor("#0a0a1a"))

        // Set up root layout
        rootLayout = FrameLayout(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#0a0a1a"))
        }

        // Set up WebView for HTML5 game
        webView = WebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#0a0a1a"))
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }

        // Set up Banner Container (Anchored at the bottom of the screen)
        bannerContainer = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            }
            setBackgroundColor(Color.parseColor("#0a0a1a"))
            visibility = View.GONE
        }

        rootLayout.addView(webView)
        rootLayout.addView(bannerContainer)
        setContentView(rootLayout)

        // Initialize AdMob Manager with event dispatcher
        adMobManager = AdMobManager(this, bannerContainer, object : AdMobManager.AdEventListener {
            override fun onAdEvent(eventType: String, payloadJson: String) {
                if (::bridge.isInitialized) {
                    bridge.dispatchEventToWeb(eventType, payloadJson)
                }
            }
        })

        // Initialize Bridge Interface
        bridge = AdBridgeInterface(this, webView, adMobManager)
        webView.addJavascriptInterface(bridge, "NeonFlipNativeBridge")
        webView.addJavascriptInterface(bridge, "AndroidBridge")

        // Configure WebView settings
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.allowFileAccessFromFileURLs = true
        settings.allowUniversalAccessFromFileURLs = true
        settings.databaseEnabled = true
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        settings.cacheMode = WebSettings.LOAD_DEFAULT

        // Asset loader for secure modern asset serving
        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                consoleMessage?.let {
                    Log.d("NeonFlip_WebConsole", "[${it.messageLevel()}] ${it.message()} -- line ${it.lineNumber()} of ${it.sourceId()}")
                }
                return true
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val url = request?.url ?: return null
                return assetLoader?.shouldInterceptRequest(url)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                Log.i(TAG, "Neon Flip HTML5 loaded successfully: $url")
                // Tell the game that native runtime is available
                val initStatus = adMobManager.getAdStatusJson()
                webView.evaluateJavascript(
                    "if(window.NeonFlipAdBridge && typeof window.NeonFlipAdBridge.onNativeReady === 'function') { window.NeonFlipAdBridge.onNativeReady($initStatus); }",
                    null
                )
            }
        }

        // Handle back button smoothly
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                webView.evaluateJavascript(
                    "if(window.NeonFlipGame && typeof window.NeonFlipGame.handleBackPress === 'function') { window.NeonFlipGame.handleBackPress(); } else { 'default'; }",
                ) { result ->
                    if (result == "\"default\"" || result == "null" || result == null) {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                        isEnabled = true
                    }
                }
            }
        })

        // Load entry HTML
        webView.loadUrl("file:///android_asset/public/index.html")
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
        adMobManager.onResume()
        webView.evaluateJavascript("if(window.NeonFlipGame && typeof window.NeonFlipGame.resume === 'function') { window.NeonFlipGame.resume(); }", null)
    }

    override fun onPause() {
        super.onPause()
        webView.onPause()
        adMobManager.onPause()
        webView.evaluateJavascript("if(window.NeonFlipGame && typeof window.NeonFlipGame.pause === 'function') { window.NeonFlipGame.pause(); }", null)
    }

    override fun onDestroy() {
        adMobManager.onDestroy()
        webView.apply {
            stopLoading()
            removeJavascriptInterface("NeonFlipNativeBridge")
            removeJavascriptInterface("AndroidBridge")
            destroy()
        }
        super.onDestroy()
    }
}
