package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Neon Flip", appName)
  }

  @Test
  fun `verify debug ad unit configuration`() {
    // In debug unit tests, AdMob IDs must be official Google test IDs
    assertNotNull(BuildConfig.ADMOB_BANNER_ID)
    assertNotNull(BuildConfig.ADMOB_INTERSTITIAL_ID)
    assertNotNull(BuildConfig.ADMOB_REWARDED_ID)
    assertTrue("Debug build should be marked as debug ads", BuildConfig.IS_DEBUG_ADS)
    assertEquals("ca-app-pub-3940256099942544/6300978111", BuildConfig.ADMOB_BANNER_ID)
    assertEquals("ca-app-pub-3940256099942544/1033173712", BuildConfig.ADMOB_INTERSTITIAL_ID)
    assertEquals("ca-app-pub-3940256099942544/5224354917", BuildConfig.ADMOB_REWARDED_ID)
  }
}
